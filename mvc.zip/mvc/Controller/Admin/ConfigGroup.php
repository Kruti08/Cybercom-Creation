<?php 

namespace Controller\Admin;

\Mage::loadFileByClassName('Controller\Core\Admin');

class ConfigGroup extends \Controller\Core\Admin
{
	public function __construct(){
        parent::__construct();
    }

	public function gridAction()
	{
		$grid = \Mage::getBlock('Block\Admin\ConfigGroup\Grid');
		$layout = $this->getLayout();
		$layout->setTemplate('./core/layout/one_column.php');
		$layout->getChild("Content")->addChild($grid,'Grid');
		$this->renderLayout();
	}

	public function formAction()
	{
		$form = \Mage::getBlock('Block\Admin\ConfigGroup\Edit');
		$layout = $this->getLayout();
		$configGroupTab = \Mage::getBlock("block\admin\configGroup\Edit\Tabs");
        $layout->getChild('Sidebar')->addChild($configGroupTab, 'Tab');
		$layout->getChild('Content')->addChild($form,'Grid');
		$this->renderLayout();
	}

	public function saveAction()
	{
		$configGroup = \Mage::getModel('Model\ConfigGroup');
		try {
			if (!$this->getRequest()->isPost()) {
			throw new \Exception("Invalid Request", 1);
		}
			if (!$configGroup) {
				throw new \Exception("Invalid Data", 1);
			}
			$groupId = $this->getRequest()->getGet('id');
			if (!$groupId) {
				date_default_timezone_set('Asia/Kolkata');
	            $configGroup->createdDate = date("Y-m-d H:i:s");
				$this->getMessage()->setSuccess('Record Inserted Successfully!');
			}
			$configGroupData = $this->getRequest()->getPost('configGroup');
			$configGroup->setData($configGroupData);
			$configGroup->save();
		} catch (Exception $e) {
			$this->getMessage()->setFailure($e->getMessage());
		}
		$this->redirect('grid',null,null,true);
	}

	public function deleteAction()
	{
		$configGroup = \Mage::getModel('Model\ConfigGroup');
		$id = $this->getRequest()->getGet('id');
		try {
			if (!$id) {
				throw new \Exception("Invalid ID", 1);
			}
			if ($configGroup->delete($id)) {
				$this->getMessage()->setSuccess('Record Deleted Successfully');
			}
		} catch (\Exception $e) {
			$this->getMessage()->setFailure($e->getMessage());
		}
		$this->redirect('grid',null,null,true);
	}
}
 ?>