<?php

namespace Controller\Admin;

\Mage::loadFileByClassName('controller\core\admin');

class CustomerGroup extends \Controller\Core\Admin{ 

    public function __construct(){
        parent::__construct();
    }
   
    public function gridAction()
    {
        $gridBlock = \Mage::getBlock("block\admin\customerGroup\grid");
        $layout = $this->getLayout()->setTemplate("./core/layout/one_column.php");;
        $layout->getChild("Content")->addChild($gridBlock,'Grid');
        $this->renderLayout();
    }

    public function formAction()
    {
        $form = \Mage::getBlock('block\admin\customerGroup\edit');
        $layout = $this->getLayout();
        $customerGroupTab = \Mage::getBlock("block\admin\customerGroup\Edit\Tabs");
        $layout->getChild('Sidebar')->addChild($customerGroupTab, 'Tab');
        $layout->getChild('Content')->addChild($form,'Grid');
        $this->renderLayout();
    }
   
    public function saveAction()
    {
        try 
        { 
            $customerGroup = \Mage::getModel("Model\customerGroup");
            if(!$this->getRequest()->isPost())
            {
                throw new \Exception("Invalid Post Request");
            }
            $customerGroupId =$this->getRequest()->getGet('id');
            if (!$customerGroupId) {
                date_default_timezone_set('Asia/Kolkata');
                $customerGroup->createdDate = date("Y-m-d H:i:s");
                $this->getMessage()->setSuccess("Customer Group Inserted Successfully");
            }
            else{
                $customerGroup =  $customerGroup->load($customerGroupId);
                if (!$customerGroup) {
                    throw new \Exception("Data Not Found");
                }
                $this->getMessage()->setSuccess("Customer Group Updated Successfully");
            }   
        
            $customerGroupData = $this->getRequest()->getPost('customerGroup');
            if(!array_key_exists('status',$customerGroupData)){
                $customerGroupData['status']=0;
            }					
            else{
                $customerGroupData['status']=1;
            }
            $customerGroup->setData($customerGroupData);  
            $customerGroup->save();
            
        } 
        catch (\Exception $e) 
        {
            $this->getMessage()->setFailed($e->getMessage());
        }   
        $this->redirect('grid',null,null,true);       
    }  

	public function deleteAction(){
		try {
			if($this->request->isPost())
            {
                throw new \Exception("Invalid Request");
            }
			
			$id = $this->getRequest()->getGet('id');
			$customerGroup = \Mage::getModel('model\customerGroup');
            if($customerGroup->delete($id)){
                $this->getMessage()->setSuccess("Customer Group Deleted SuccessFully !!"); 
            }else{
                $this->getMessage()->setFailure("Unable to Delete Customer Group!!"); 
            }
		} catch (\Exception $e) {
			$this->getMessage()->setFailure($e->getMessage()); 
		}
        $this->redirect('grid',null,null,true);
	}
}
?>

