<?php 

namespace Controller\Admin;

\Mage::loadFileByClassName('Controller\Core\Admin');

class Cart extends \Controller\Core\Admin
{
	public function addItemToCartAction()
	{
		try{
			$productId = $this->getRequest()->getGet('id');
			if(!$id=$this->getRequest()->getGet('id')){
				throw new Exception("Product ID Invalid", 1); 
			}
			$product = \Mage::getModel('Model\Product')->load($id);
			$cart = $this->getCart();
			$cart->addItemToCart($product,1,True);
		}
		catch (\Exception $e) 
        {
            $this->getMessage()->setFailure($e->getMessage()); 
        }  
        $this->redirect('grid',null);       
	}

	public function selectCustomerAction()
	{
		$id = $this->getRequest()->getPost('customerId');
		$this->getCart($id);
		$this->redirect('grid',null,null,true);
	}

	protected function getCart($customerId = null){
		$session = \Mage::getModel('Model\Admin\Session');
		$cart = \Mage::getModel('Model\Cart');
		if ($customerId) {
			$session->customerId = $customerId;
		}
		$cart = $cart->load($session->customerId,'customerId');
        if (!$cart) {
            $cart = \Mage::getModel('Model\Cart');
            $cart->customerId = $customerId;
            date_default_timezone_set('Asia/Kolkata');
            $cart->createdDate = date("Y-m-d H:i:s");
            $cart->save();
        }
        return $cart;
	}
	
	public function gridAction()
	{ 
		$grid = \Mage::getBlock('Block\Admin\Cart\Grid');
		$layout = $this->getLayout();
        $layout->setTemplate("./core/layout/one_column.php");
        $cart = $this->getCart();
        $grid->setCart($cart);
        $layout->getChild("Content")->addChild($grid,'Grid');
        $this->renderLayout();
	}

	public function updateAction()
	{
        $data['price'] = $this->getRequest()->getPost('price');
        $data['quantity'] = $this->getRequest()->getPost('quantity'); 
        $cart = $this->getCart();
		foreach ($data as $key => $items) {
			foreach ($items as $itemId => $value) {
				$cartItem = \Mage::getModel('Model\Cart\Item')->load($itemId);
				$cartItem->$key=$value; 
				$cartItem->save();
			}
		}
        $cart->total = $cart->getTotal();
        $cart->discount = $cart->getDiscount();
        $cart->save();
        $this->redirect('grid');
	}

	public function saveCustomerBillingAddressAction()
	{
        try{
			if (!$this->getRequest()->getPost()) {
				throw new \Exception("Invalid Request !!", 1);
			}

			$cart = $this->getCart();
			$billingData = $this->getRequest()->getPost('billing');

			if (!$billingData) {
				throw new \Exception("Invalid Data !!", 1);
			}

			if ($cart->getBillingAddress()) {
				$cart->getBillingAddress()->setData($billingData)->save();
			}
			else {
				$address = \Mage::getModel('Model\Cart\Address');
                $address->setData($billingData);
                $address->cartId = $cart->cartId;
                $address->save();
			}

			if ($this->getRequest()->getPost('saveBillingAddress')) {
                $customerAddress = $cart->getCustomerBillingAddress();
                if ($customerAddress) {
                    $customerAddress->setData($billingData)->save();
                } else {
                    $customerAddress = \Mage::getModel('Model\CustomerAddress');
                    $cartAddress = $cart->getBillingAddress();
                    $customerAddress->zipcode = $cartAddress->zipcode;
                    $customerAddress->country = $cartAddress->country;
                    $customerAddress->state = $cartAddress->state;
                    $customerAddress->address = $cartAddress->address;
                    $customerAddress->city = $cartAddress->city;
                    $customerAddress->type = $cartAddress->addressType;
                    $customerAddress->customer_id = $cart->customerId;
                    $customerAddress->save();
                }
            }

            if ($this->getRequest()->getPost('sameAsShippingAddress')) {
               
                if ($cart->getShippingAddress()) {
                    $shipping = $cart->getShippingAddress();
                    $billing = $cart->getBillingAddress();
                    $billing->zipcode = $shipping->zipcode;
                    $billing->country = $shipping->country;
                    $billing->state = $shipping->state;
                    $billing->address = $shipping->address;
                    $billing->city = $shipping->city;
                    $billing->cartId = $cart->cartId;
                    $billing->save();
                } else {
                    $shipping = \Mage::getModel('Model\Cart\Address');
                    $billing = $cart->getBillingAddress();
                    $shipping->zipcode = $billing->zipcode;
                    $shipping->country = $billing->country;
                    $shipping->state = $billing->state;
                    $shipping->address = $billing->address;
                    $shipping->city = $billing->city;
                    $shipping->cartId = $cart->cartId;
                    $shipping->addressType = 'Shipping';
                    $shipping->save();
                }
            }
            $this->redirect('grid');
		} catch (\Exception $e){
			$this->getMessage()->setFailure($e->getMessage());
		}

	}

	public function saveCustomerShippingAddressAction()
    {
        try {
            if (!$this->getRequest()->isPost()) {
                throw new \Exception('Invalid Request.');
            }

            $cart = $this->getCart();
            $shippingData = $this->getRequest()->getPost('shipping');

            if (!$shippingData) {
                throw new \Exception('Invalid data.');
            }
            if ($cart->getShippingAddress()) {
                $cart->getShippingAddress()->setData($shippingData)->save();
            } else {
                $address = \Mage::getModel('Model\Cart\Address');
                $address->setData($shippingData);
                $address->cartId = $cart->cartId;
                $address->save();
            }

            if ($this->getRequest()->getPost('saveShippingAddress')) {
                $customerAddress = $cart->getShippingAddress();
                if ($customerAddress) {
                    $customerAddress->setData($shippingData);
                    $customerAddress->save();
                } else {
                    $customerAddress = \Mage::getModel('Model\Customer\Address');
                    $cartAddress = $cart->getShippingAddress();
                    $customerAddress->zipcode = $cartAddress->zipcode;
                    $customerAddress->country = $cartAddress->country;
                    $customerAddress->state = $cartAddress->state;
                    $customerAddress->address = $cartAddress->address;
                    $customerAddress->city = $cartAddress->city;
                    $customerAddress->type = $cartAddress->addressType;
                    $customerAddress->customer_id = $cart->customerId;
                    $customerAddress->save();
                }
            }

            if ($this->getRequest()->getPost('sameAsBillingAddress')) {
                if ($cart->getBillingAddress()) {
                    $shipping = $cart->getShippingAddress();
                    $billing = $cart->getBillingAddress();
                    $shipping->zipcode = $billing->zipcode;
                    $shipping->country = $billing->country;
                    $shipping->state = $billing->state;
                    $shipping->address = $billing->address;
                    $shipping->city = $billing->city;
                    $shipping->cartId = $cart->cartId;
                    $shipping->save();
                } else {
                    $billing = \Mage::getModel('Model\Cart\Address');
                    $shipping = $cart->getShippingAddress();
                    $billing->cartId = $cart->cartId;
                    $billing->address = $shipping->address;
                    $billing->city = $shipping->city;
                    $billing->state = $shipping->state;
                    $billing->zipcode = $shipping->zipcode;
                    $billing->country = $shipping->country;
                    $billing->addressType = 'Billing';
                    $billing->save();
                }
            }
            $this->redirect('grid');

        } catch (\Exception $e) {
            $this->getMessage()->setFailure($e->getMessage());
        }
    }

    public function saveAction()
    {
        try{
            if (!$this->getRequest()->isPost()) {
                throw new \Exception('Invalid Request.');
            }

            $shippingMethodId = $this->getRequest()->getPost('shippingMethodId');
            $paymentMethodId = $this->getRequest()->getPost('paymentMethodId'); 
            $cart = $this->getCart();

            if ($shippingMethodId) {
                $cart->shippingMethodId = $shippingMethodId;
            }
            if ($paymentMethodId) {
                $cart->paymentMethodId = $paymentMethodId;
            }
            $cart->total = $cart->getTotal();
            $cart->discount = $cart->getDiscount();
            $cart->shippingAmount = $cart->getShippingAmount();
            $cart->save();
            $this->redirect('grid');
        } catch(\Exception $e){
            $this->getMessage()->setFailure($e->getMessage());
        }
    }
}

 ?>