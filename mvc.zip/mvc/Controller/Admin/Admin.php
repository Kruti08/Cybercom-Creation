<?php

namespace Controller\Admin;

\Mage::loadFileByClassName('controller\core\admin');
  
class Admin extends \Controller\Core\Admin{ 

    public function __construct(){
        parent::__construct();
        
    }

    public function gridAction()
    {
        $gridBlock = \Mage::getBlock("block\admin\admin\grid");
        $layout = $this->getLayout()->setTemplate("./core/layout/one_column.php");
        $layout->getChild("Content")->addChild($gridBlock,'Grid');
        $this->renderLayout();
    }

    public function formAction(){

        $form = \Mage::getBlock('block\admin\admin\edit');
        $layout = $this->getLayout();
        $adminTab = \Mage::getBlock("block\admin\admin\Edit\Tabs");
        $layout->getChild('Sidebar')->addChild($adminTab, 'Tab');
        $layout->setTemplate("./core/layout/two_column_leftBar.php");
        $layout->getChild('Content')->addChild($form,'Grid');
        $this->renderLayout();
    }
   
    public function saveAction()
    {
        try 
        { 
            $admin = \Mage::getModel("Model\admin");
            if(!$this->getRequest()->isPost())
            {
                throw new \Exception("Invalid Post Request");
            }
            $adminId =$this->getRequest()->getGet('id');
            if ($adminId) { 
                $admin =  $admin->load($adminId);
                if (!$admin) {
                    throw new \Exception("Data Not Found");
                }
                $this->getMessage()->setSuccess("Admin Updated Successfully !!");
            }   
            else{
                $this->getMessage()->setSuccess("Admin Inserted Successfully !!");
            }
            $adminData = $this->getRequest()->getPost('admin');
            
            if(!array_key_exists('status',$adminData)){
                $adminData['status']=0;
            }					
            else{
                $adminData['status']=1;
            }
            $admin->setData($adminData);
            $admin->createdDate = date("Y-m-d H:i:s"); 
            $admin->save();
        } 
        catch (\Exception $e) 
        {
            $this->getMessage()->setFailure($e->getMessage());
        }          
        $this->redirect('grid',null,null,true);
    }

	public function deleteAction(){
		try{
            if (!$id = $this->getRequest()->getGet('id')) {
                throw new \Exception("Invalid Id", 1);
            }
            else{
                $admin = \Mage::getModel('Model\Attribute\Admin');
                if ($admin->delete($id)) {
                    $this->getMessage()->setSuccess('Record Deleted Successfully !!');
                }
                else{
                    $this->getMessage()->setFailure('Unable to delete the record !!');
                }
            }
        }
        catch (\Exception $e){
            $this->getMessage()->setFailure($e->getMessage());
        }
        $this->redirect('grid',null,null,true);
	}
}
?>

