<?php 

namespace Controller\Admin\ConfigGroup;
use Exception;

\Mage::loadFileByClassName('Controller\Core\Admin');

class Config extends \Controller\Core\Admin
{
	function __construct()
	{
		parent::__construct();
	}

	public function saveAction()
	{
		try{
			if (!$this->getRequest()->isPost()) {
				throw new Exception("Invalid Request", 1);
			}
			$id = $this->getRequest()->getGet('id');
			$configData = $this->getRequest()->getPost();

			if (array_key_exists('new', $configData)) {
				foreach ($configData['new']['title'] as $key => $configs) {
                    $config = \Mage::getModel('Model\ConfigGroup\Config');
                    $config->groupId = (int)$id;
                    $config->title = $configs;
                    $config->code = $configData['new']['code'][$key];
                    $config->value = $configData['new']['value'][$key];
                    date_default_timezone_set('Asia/Kolkata');
                    $config->createdDate = date('Y-m-d i:m:s');
                    if ($config->save()) {
                    	$this->getMessage()->setSuccess("Config Inserted Successfully !");
                    }
                }
			}

            if (array_key_exists('existing', $configData)) {
				foreach ($configData['existing'] as $configId => $configs) {
					$config = \Mage::getModel('Model\ConfigGroup\Config');
					$config = $config->load($configId);
					$config->title = $configs['title'];
					$config->code = $configs['code'];
					$config->value = $configs['value'];
					$config->save();
				}
			}
		}
		catch(Exception $e){
			$this->getMessage()->setFailure($e->getMessage());
		}
		$this->redirect('grid','ConfigGroup');
	}

	public function deleteAction()
	{
		try{
			if (!$id = $this->getRequest()->getGet('id')) {
				throw new Exception("Invalid Id", 1);
			}
			else{
				$config = \Mage::getModel('Model\ConfigGroup\Config');
				if ($config->delete($id)) {
					$this->getMessage()->setSuccess('Record Deleted Successfully !!');
				}
				else{
					$this->getMessage()->setFailure('Unable to delete the message !!');
				}
			}
		}
		catch (Exception $e){
			$this->getMessage()->setFailure($e->getMessage());
		}
		$this->redirect('grid','ConfigGroup',null,true);
	}
}

 ?>