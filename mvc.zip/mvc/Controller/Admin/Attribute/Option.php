<?php

namespace Controller\Admin\Attribute;

\Mage::loadFileByClassName('Controller\Core\Admin');

class Option extends \Controller\Core\Admin
{
    public function __construct()
    {
        parent::__construct();
    }

    public function saveAction()
    {
        try {
            if (!$this->getRequest()->isPost()) {
                throw new \Exception("Invalid Post Request", 1);
            }
            $optionData = $this->getRequest()->getPost();
            $attributeId = $this->getRequest()->getGet('id');
            if (array_key_exists('existing', $optionData)) {
                foreach ($optionData['existing'] as $optionId => $optionValue) {
                    $optionModel = \Mage::getModel("Model\Attribute\Option");
                    $query = "Update `{$optionModel->getTableName()}` set `name`= '{$optionValue['name']}', `sortOrder`='{$optionValue['sortOrder']}' where  `attributeId`={$attributeId} and `optionId`={$optionId}";

                    if ($optionModel->update($query)) {
                        $this->getMessage()->setSuccess("Option Updated SuccessFully !!");
                    }
                }
            }
            if (array_key_exists('new', $optionData)) {

                $optionData['new'] = array_combine($optionData['new']['name'], $optionData['new']['sortOrder']);
                foreach ($optionData['new'] as $name => $sortOrder) {
                    if ($name) {
                        $optionModel = \Mage::getModel("Model\Attribute\Option");
                        $optionModel->attributeId  = $attributeId;
                        $optionModel->name = "$name";
                        $optionModel->sortOrder = "$sortOrder";
                        if ($optionModel->save()) {
                            $this->getMessage()->setSuccess("Option Updated SuccessFully !!");
                        }
                    }
                }
            }
        } catch (\Exception $e) {
            $this->getMessage()->setFailure($e->getMessage());
        }

        $this->redirect('form', 'attribute', null, true);
    }

    public function deleteAction()
    {
        try{
            if (!$id = $this->getRequest()->getGet('id')) {
                throw new \Exception("Invalid Id", 1);
            }
            else{
                $option = \Mage::getModel('Model\Attribute\Option');
                if ($option->delete($id)) {
                    $this->getMessage()->setSuccess('Record Deleted Successfully !!');
                }
                else{
                    $this->getMessage()->setFailure('Unable to delete the record !!');
                }
            }
        }
        catch (\Exception $e){
            $this->getMessage()->setFailure($e->getMessage());
        }
        $this->redirect('form','Attribute',null,true);
    }
}
