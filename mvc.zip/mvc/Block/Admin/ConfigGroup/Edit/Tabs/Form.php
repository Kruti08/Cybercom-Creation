<?php 

namespace Block\Admin\ConfigGroup\Edit\Tabs;

\Mage::loadFileByClassName('Block\Core\Template');

class Form extends \Block\Core\Template
{
	protected $configGroup = null;

	function __construct()
	{
		$this->setTemplate('./admin/ConfigGroup/edit/tabs/form.php');
	} 

	public function setConfigGroup($configGroup = null)
    {
        $request = \Mage::getModel('Model\Core\Request');
        if (!$configGroup) 
        {
            $configGroup = \Mage::getModel("Model\ConfigGroup");
            if ($id = $request->getGet('id')) 
            {
                $configGroup = $configGroup->load($id);
                if (!$configGroup) {
                    $configGroup =\Mage::getModel("Model\ConfigGroup");
                }
            }  
        }
        $this->configGroup = $configGroup;
        return $this;
    }
    public function getConfigGroup()
    {
        if (!$this->configGroup) {
            $this->setConfigGroup();
        }
        return $this->configGroup;     
    }  
}

 ?>