<?php 

namespace Block\Admin\ConfigGroup\Edit\Tabs;

\Mage::loadFileByClassName('Block\Core\Template');

class Config extends \Block\Core\Template
{
	protected $configs = null;

	function __construct()
	{
		$this->setTemplate('./admin/configGroup/edit/tabs/config.php');
	}

	public function setConfigs($configs = null)
	{
		$request = \Mage::getModel('Model\Core\Request');
		if (!$configs) {
			$configs = \Mage::getModel('Model\ConfigGroup\Config');
			if ($id=$request->getGet('id')) {
				$query = "SELECT * FROM `{$configs->getTableName()}` WHERE `groupId` = {$id}";
				$configs = $configs->fetchAll($query);
				if (!$configs) {
					return $this;
				}
			}
		}
		$this->configs=$configs;
		return $this;
	}

	public function getConfigs()
	{
		if (!$this->configs) {
			$this->setConfigs();
		}
		return $this->configs;
	}

}

 ?>