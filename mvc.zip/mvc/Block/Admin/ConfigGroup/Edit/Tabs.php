<?php

namespace Block\Admin\ConfigGroup\Edit;

\Mage::loadFileByClassName("Block\Core\Edit\Tabs");

class Tabs extends \Block\Core\Edit\Tabs
{
    protected $tabs = [];
    protected $default = null;
    public function __construct() 
    {
        parent::__construct();
        $this->setTemplate("./admin/configGroup/edit/tabs.php");
        $this->prepareTab();
    }

    public function prepareTab()
    {
        $this->addTab('ConfigGroup', ["label" => "Config Group Information", "className" => 'Block\Admin\ConfigGroup\Edit\Tabs\Form']);
        if($this->getRequest()->getGet('id')){
            $this->addTab('Config', ["label" => "Config Information", "className" => 'Block\Admin\ConfigGroup\Edit\Tabs\Config']);
        }
        $this->setDefault('ConfigGroup');
    }
}
