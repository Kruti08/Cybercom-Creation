<?php 

namespace Block\Admin\ConfigGroup;

\Mage::loadFileByClassName('Block\Core\Template');

class Grid extends \Block\Core\Template
{
	protected $configGroups = null;

	function __construct()
	{
		$this->setTemplate('./admin/configGroup/grid.php');
	}

	public function setConfigGroups($configGroups = null)
	{
		if (!$configGroups) {
			$configGroup = \Mage::getModel('Model\ConfigGroup');
			$configGroups = $configGroup->fetchAll();
		}
		$this->configGroups = $configGroups;
		return $this;
	}

	public function getConfigGroups()
	{
		if (!$this->configGroups) {
			$this->setConfigGroups();
		}
		return $this->configGroups;
	}

	public function getTitle()
	{
		return 'Manage Config Groups';
	}
}

 ?>