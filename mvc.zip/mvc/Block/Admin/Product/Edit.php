<?php

namespace Block\Admin\Product;

\Mage::loadFileByClassName('block\core\Template');

class Edit extends \Block\Core\Template{
  protected $products = null;
  public function __construct()
  {
      parent::__construct();
      $this->setTemplate('./admin/product/edit.php');
  }
   
  public function getTabContent()
  {
        $tabsBlock = \Mage::getBlock("block\Admin\product\Edit\Tabs");
        $tabs = $tabsBlock->getTabs();
        $fetchTab = $this->getRequest()->getGet('tab'); //product1 
         if(!array_key_exists($fetchTab,$tabs))   // product1  
         {
            $fetchTab = $tabsBlock->getDefault();   // product1 = product 
         }
         $gotTab = \Mage::getBlock($tabs[$fetchTab]['className']); //tabs[product][block_];
         echo $gotTab->toHtml();

  }

}

?>