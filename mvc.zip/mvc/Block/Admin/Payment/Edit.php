<?php

namespace Block\Admin\Payment;

\Mage::loadFileByClassName('block\core\Template');

class Edit extends \Block\Core\Template{
  
  public function __construct()
  {
      parent::__construct();
      $this->setTemplate('./admin/payment/edit.php');
  }
  
  public function getTabContent()
  {
    $tabsBlock = \Mage::getBlock("block\admin\payment\Edit\Tabs");
    $tabs = $tabsBlock->getTabs();
    $fetchTab = $this->getRequest()->getGet('tab');
    if (!array_key_exists($fetchTab, $tabs)) {
      $fetchTab = $tabsBlock->getDefault();
    }
    $gotTab = \Mage::getBlock($tabs[$fetchTab]['className']);
    echo $gotTab->toHtml();
  }

}

?>