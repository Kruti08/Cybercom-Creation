<?php

namespace Block\Admin\Cms;

\Mage::loadFileByClassName('block\core\template');

class Grid extends \Block\Core\Template
{

    protected $cmsies = null;
    protected $message = null;

    public function __construct()
    {
        parent::__construct();
        $this->setTemplate('./admin/cms/grid.php');
    }
    public function setCms($cmsies = null)
    {
        if (!$cmsies) {
            $cmsies = \Mage::getModel("Model\Cms");
            $cmsies = $cmsies->fetchAll();
        }
        $this->cmsies = $cmsies;
        return $this;
    }
    public function getCms()
    {
        if (!$this->cmsies) {
            $this->setCms();
        }
        return $this->cmsies;
    }
    public function getTitle()
    {
        return "Manage CMS Pages";
    }

}
