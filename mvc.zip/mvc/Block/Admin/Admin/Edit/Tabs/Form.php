<?php

namespace Block\Admin\Admin\Edit\Tabs;

\Mage::loadFileByClassName("block\core\Template");

class Form extends \Block\Core\Template
{
    protected $admins = null;
    public function __construct()
    {
        parent::__construct();
        $this->setTemplate("./admin/admin/edit/tabs/form.php");
    }

    public function setAdmin($admins = null)
    {
        if (!$admins) 
        {
            $admins = \Mage::getModel("Model\admin");
            if ($id = $this->getRequest()->getGet('id')) 
            {
                $admins = $admins->load($id);
            }  
        }
        $this->admins = $admins;    
        return $this;
    }

    public function getAdmin()
    {
        if (!$this->admins) {
            $this->setAdmin();
        }
        return $this->admins;     
    }  
}
