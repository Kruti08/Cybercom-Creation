<?php 

namespace Block\Admin\Cart;

\Mage::getBlock("Block\Core\Template");

class Checkout extends \Block\Core\Template
{
	protected $paymentMethods = [];
    protected $shippingMethods = []; 
    protected $cart = null;

	function __construct()
	{
		$this->setTemplate('./admin/cart/checkout.php');
	}

	public function setCart(\Model\Cart $cart)
	{
		$this->cart=$cart;
		return $this;
	}
 
	public function getCart()
	{
		if (!$this->cart) {
			throw new \Exception("Cart is not found", 1);
		}
		return $this->cart;
	}

	public function setPaymentMethods($paymentMethods = null)
    {
        if ($paymentMethods) {
            $this->paymentMethods = $paymentMethods;
            return $this;
        }
        $payment = \Mage::getModel('Model\Payment');
        $query = "SELECT * FROM `{$payment->getTableName()}` WHERE `status` = 1";
        $paymentMethods = $payment->fetchAll($query);
        if (!$paymentMethods) {
            return null;
        }
        $this->paymentMethods = $paymentMethods;
        return $this;
    }

    public function getPaymentMethods()
    {
        if (!$this->paymentMethods) {
            $this->setPaymentMethods();
        }
        return $this->paymentMethods;
    }

    public function setShippingMethods($shippingMethods = null)
    {
        if ($shippingMethods) {
            $this->shippingMethods = $shippingMethods;
            return $this;
        }
        $shipping = \Mage::getModel('Model\Shipment');
        $query = "SELECT * FROM `{$shipping->getTableName()}` WHERE `status` = 1";
        $shippingMethods = $shipping->fetchAll($query);
        if (!$shippingMethods) {
            return null;
        }
        $this->shippingMethods = $shippingMethods;
        return $this;
    }

    public function getShippingMethods()
    {
        if (!$this->shippingMethods) {
            $this->setShippingMethods();
        }
        return $this->shippingMethods;
    }
}

 ?>