<?php 

namespace Block\Admin\Cart;

\Mage::loadFileByClassName('Block\Core\Template');

class Grid extends \Block\Core\Template
{
	protected $cart = null;	

	function __construct()
	{
		$this->setTemplate('./admin/cart/grid.php');
	}

	public function setCart(\Model\Cart $cart)
	{
		$this->cart=$cart;
		return $this;
	}

	public function getCart()
	{
		if (!$this->cart) {
			throw new \Exception("Cart is not found", 1);
		}
		return $this->cart;
	}

	public function getItems()
	{
		$items = $this->getCart()->getItems();
		return $items;
	}

	public function getCustomers()
	{
		$customers = \Mage::getModel('Model\Cart')->getCustomers();
		return $customers;
	}
}
 ?>