<?php  $billingAddress = $this->getBillingAddress(); ?>
<?php  $shippingAddress = $this->getShippingAddress(); ?>
<hr><br>
<div class="row">
	<div class="col s6">
		<div class="row" style="margin-left: 40px; margin-right: 40px;">
			<h5>Billing Address</h5>
		    	<div class="row">
        			<div class="input-field col s12">
          				<textarea id="address" name="billing[address]" class="materialize-textarea" ><?php echo $billingAddress->address; ?></textarea>
          				<label for="address">Address</label>
        			</div>
        		</div>
		      <div class="row">
		        <div class="input-field col s6">
		          <input id="city" name="billing[city]" value="<?php echo $billingAddress->city ?>" type="text" class="validate">
		          <label for="city">City</label>
		        </div>
		        <div class="input-field col s6">
		          <input id="state" name="billing[state]" value="<?php echo $billingAddress->state ?>" type="text" class="validate">
		          <label for="state">State</label>
		        </div>
		      </div>
		      <div class="row">
		        <div class="input-field col s6">
		          <input id="country" name="billing[country]" value="<?php echo $billingAddress->country ?>" type="text" class="validate">
		          <label for="country">Country</label>
		        </div>
		        <div class="input-field col s6">
		          <input id="zipcode" name="billing[zipcode]" type="text" class="validate" value="<?php echo $billingAddress->zipcode ?>">
		          <label for="zipcode">Zipcode</label>
		        </div>		   
		      </div>
		      <div class="row">
		      	<label>
        			<input type="checkbox" name="sameAsShippingAddress" class="filled-in"  />
        			<span>Same as Shippingn Address</span>
      			</label><br>
      			<label>
        			<input type="checkbox" name="saveBillingAddress" class="filled-in" />
        			<span>Save Billing address in Customer Address</span>
      			</label>
		      </div>
		      <div class="row">
		      	<button type="submit" class="submit" onclick="saveCustomerBillingAddress();">Save</button>
		      </div>
  		</div>
	</div>
	<div class="col s6">
		<div class="row" style="margin-right: 40px; margin-left: 40px;">
			<h5>Shipping Address</h5>
		    	<div class="row">
        			<div class="input-field col s12">
          				<textarea id="address" name="shipping[address]" class="materialize-textarea"><?php echo $shippingAddress->address ?></textarea>
          				<label for="address">Address</label>
        			</div>
        		</div>
		      <div class="row">
		        <div class="input-field col s6">
		          <input id="city" name="shipping[city]" value="<?php echo $shippingAddress->city ?>" type="text" class="validate">
		          <label for="city">City</label>
		        </div>
		        <div class="input-field col s6">
		          <input id="state" name="shipping[state]" value="<?php echo $shippingAddress->state ?>" type="text" class="validate">
		          <label for="state">State</label>
		        </div>
		      </div>
		      <div class="row">
		        <div class="input-field col s6">
		          <input id="country" name="shipping[country]" value="<?php echo $shippingAddress->country ?>" type="text" class="validate">
		          <label for="country">Country</label>
		        </div>
		        <div class="input-field col s6">
		          <input id="zipcode" name="shipping[zipcode]" value="<?php echo $shippingAddress->zipcode ?>" type="text" class="validate">
		          <label for="zipcode">Zipcode</label>
		        </div>		   
		      </div>
		      <div class="row">
		      	<label>
        			<input type="checkbox" name="sameAsBillingAddress" class="filled-in" />
        			<span>Same as Billing Address</span>
      			</label><br>
      			<label>
        			<input type="checkbox" name="saveShippingAddress" class="filled-in" />
        			<span>Save Shipping address in Customer Address</span>
      			</label>
		      </div>
		      <div class="row">
		      	<button type="submit" class="submit" onclick="saveCustomerShippingAddress();">Save</button>
		      </div>
  		</div>
	</div>
</div>