<?php $cart = $this->getCart(); ?>
<?php $paymentMethods = $this->getPaymentMethods()->getData();  ?> 
<?php $shippingMethods = $this->getShippingMethods()->getData();  ?>
<div class="card text-left" style="margin-left: 40px; margin-right: 40px;">
    <div class="card-body">
	<div class="row">
	    <div class="col s4">
	        <h5>Select Payment Method</h5>
				<?php if (!$paymentMethods): echo "<h6>No payments Method found</h6>"?>
				<?php else: ?>
				<?php foreach ($paymentMethods as $key => $paymentMethod ) : ?>
					<label>
				        <input class="with-gap" name="paymentMethodId" type="radio" value="<?php echo $paymentMethod->methodId; ?>" <?php if ($paymentMethod->methodId == $cart->paymentMethodId): ?>checked="checked" <?php endif;?>  />
	        			<span><?php echo $paymentMethod->name ?></span>
	     			</label><br>
				<?php endforeach; ?>
				<?php endif; ?>
	    </div>
	    <div class="col s4">
	        <h5>Select Shipping Method</h5>
				<?php if (!$shippingMethods): echo "<h6>No payments Method found</h6>"?>
				<?php else: ?>
				<?php foreach ($shippingMethods as $key => $shippingMethod) : ?>
					<label>
				        <input class="with-gap" name="shippingMethodId" type="radio" value="<?php echo $shippingMethod->methodId; ?>" <?php if ($shippingMethod->methodId == $cart->shippingMethodId): ?>checked="checked" <?php endif;?>  />
	        			<span><?php echo $shippingMethod->name ?></span>
	     			</label><br>
				<?php endforeach; ?>
				<?php endif; ?> 
		</div>
		<div class="col s4">
	        <h5>Cart Details</h5>
	        <h6>Total : <?php echo $cart->total; ?></h6> 
	        <h6>Discount : <?php echo $cart->discount; ?></h6>
	        <h6>Shipping Amount : <?php echo $cart->shippingAmount; ?></h6> 
	        <hr>
	        <h6>Money to Pay: <?php echo ($cart->total+$cart->shippingAmount)-$cart->discount;  ?></h6>


		</div>
	</div>
<br>	
	</div>
</div>

<div class="row">
	<center><button type="submit" class="submit" onclick="saveDetails();">Save</button></center>
</div>
<br><br>

