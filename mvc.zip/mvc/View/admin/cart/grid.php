<?php $cart= $this->getCart(); ?>
<?php $cartItems = $this->getItems(); ?>
<?php $customers = $this->getCustomers(); ?>

<form method="post" id="cartForm" >
    <h6>Select Customer:</h6>
    <div class="row">
        <div class="input-field col s10">
            <select class="browser-default" name="customerId">
                <?php foreach($customers->getData() as $key => $customer): ?>
                    <option value="<?php echo $customer->customerId ?>" <?php if ($customer->customerId == $cart->customerId){
    echo 'selected';  }  ?> ><?php echo $customer->firstName ?></option> 
                <?php endforeach; ?>                
            </select>
        </div>
        <div>
            <button type="button" class="Button" onclick="selectCustomer();">Go</button>
        </div> 
    </div>
<div class="row">
    <div class="col s1"></div>
    <div class="col s7"><h5>Cart Item Details</h5></div>
    <div class="col s2"><button class="button" type="Submit" onclick="updateData();">Update Cart</button></div>
    <div class="col s2"><a class="update" href="<?php echo $this->getUrl()->getUrl('Grid','Product') ?>">Add Item</a></div></div>
</div>
<div class="row">
    <div class="col s1"></div>
    <div class="col s10">
    	<table class="heighlight">
    		<thead>
    			<th>Cart Item Id</th>
                <th>ProdcutId</th>
                <th>Quantity</th>
                <th>BasePrice</th>
                <th>Price</th>
                <th>Discount</th>
                <th>Created Date</th>
    		</thead>
    	<tbody>
    		<?php if (!$cartItems) : ?>
    		<tr>
    			<td colspan="7">No record Found</td>
    		</tr>
    		<?php else: ?>
    		<?php foreach ($cartItems->getData() as $key => $item): ?>
    		<tr>
    			<td><?php echo $item->cartItemId ?></td>
    			<td><?php echo $item->productId ?></td>
    			<td><input type="number" name="quantity[<?php echo $item->cartItemId ?>] ?>" value="<?php echo $item->quantity ?>" class="change"></td>
    			<td><?php echo $item->basePrice ?></td>
    			<td><input type="number" name="price[<?php echo $item->cartItemId ?>]?>" value="<?php echo $item->price ?>" class="change"></td>
    			<td><?php echo $item->discount ?></td>
    			<td><?php echo $item->createdDate ?></td>
    		</tr>
    	<?php endforeach; ?> 
    	<?php endif; ?>
    	</tbody>
    	</table>
    </div>
    <div class="col s1"></div>
   
</div>

<?php echo $this->createBlock('Block\Admin\Cart\Address')->setCart($cart)->toHtml(); ?>
<hr>
<?php echo $this->createBlock('Block\Admin\Cart\Checkout')->setCart($cart)->toHtml(); ?>

</form> 

<script type ="text/javascript">
    function selectCustomer(){
        var form = document.getElementById('cartForm');
        var action = form.setAttribute('Action','<?php echo $this->getUrl()->getUrl('selectCustomer'); ?>');
        form.submit();
    }

    function updateData() {
        var form = document.getElementById('cartForm');
        var action = form.setAttribute('Action','<?php echo $this->getUrl()->getUrl('Update'); ?>');
        form.submit();
    }

    function saveCustomerBillingAddress() {
        var form = document.getElementById('cartForm');
        var action = form.setAttribute('Action','<?php echo $this->getUrl()->getUrl('saveCustomerBillingAddress'); ?>');
        form.submit();
    }

    function saveCustomerShippingAddress() {
        var form = document.getElementById('cartForm');
        var action = form.setAttribute('Action','<?php echo $this->getUrl()->getUrl('saveCustomerShippingAddress'); ?>');
        form.submit();
    }

    function saveDetails() {
        var form = document.getElementById('cartForm');
        var action = form.setAttribute('Action','<?php echo $this->getUrl()->getUrl('save'); ?>');
        form.submit();
    }
</script>