<?php

   $this->getTabContent();

?>