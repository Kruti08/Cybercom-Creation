
    <div class="row">
         <div class="input-field col s12">
         <a href="<?php echo $this->getUrl()->getUrl('form');?>" class="addButton" name="update">Add Category </a>                    
        </div>
   </div>
    <div class="container-fluid">
  
        <div class="card text-left">
          <div class="card-body">
            <h4 class="card-title"><?php echo $this->getTitle(); ?></h4>
            <p class="card-text">
            <table class="highlight">
            <thead>
            <tr>
                <th>Category Name</th>
                <th>Parent Id</th>
                <th>Path Id</th>
                <th>Status</th>
                <th>Description</th>
                <th colspan="3">Action</th>
            </tr>
            </thead>
            <tbody>
            <?php
                $data = $this->getCategories();
                if($data == ""):
                    echo '<p class=text-center><strong>No Record Found</strong><p>';    
                else:
                    foreach($data->getData() as $record):
            ?>
            <tr id="txtData">
                <td><?php echo $record->categoryName ?></td>
                <td><?php echo $record->parentId ?></td>
                <td><?php echo $record->pathId ?></td>
                <td><?php 
                        if($record->status):
                            echo 'Enabled';
                        else:
                            echo 'Disabled';
                        endif;
                    ?>
                </td>
                <td><?php echo $record->description ?></td>
                <th><a href="<?php echo $this->getUrl()->getUrl('form',NULL,['id'=>$record->categoryId]); ?>"><i class="material-icons">edit</i></a></th>
                <th><a href="<?php echo $this->getUrl()->getUrl('delete',NULL,['id'=>$record->categoryId]); ?>"><i class="material-icons" >delete</i></a></th>
            </tr>
           <?php 
                endforeach;
            endif;
           ?> 
            </tbody>
        </table>
            </p>
          </div>
          
        </div>
       
    </div>  