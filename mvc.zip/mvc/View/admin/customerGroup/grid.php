<?php $customerGroups = $this->getCustomerGroups(); ?>
    <div class="row">
         <div class="input-field col s12">
         <a href="<?php echo $this->getUrl()->getUrl('form'); ?>" class="addButton" name="update">Add Customer Group</a>                    
        </div>
   </div>
        <div class="card text-left">
          <div class="card-body">
            <h4 class="card-title">Cutomer Group Details</h4>
            <p class="card-text">
            <table class="highlight">
            <thead>
            <tr>
                <th>Customer Group Id</th>
                <th>Group Name</th>
                <th>Status</th>
                <th>Created Date</th>
                <th colspan="3">Action</th>
            </tr>
            </thead>

            <tbody>
            <?php  if(!$customerGroups) : ?>
                <tr>
                    <td colspan="5"><center>No records Found</center> </td>
                </tr>
            <?php else: ?>   
            <?php foreach($customerGroups->getData() as $customerGroup): ?>
            <tr id="txtData">
                <td><?php echo $customerGroup->group_id ?></td>
                <td><?php echo $customerGroup->name ?></td>
                <td><?php if($customerGroup->status): echo 'Enabled';  ?>
                    <?php else: echo 'Disabled'; ?>    
                    <?php endif; ?>
                </td>
                <td><?php echo $customerGroup->createdDate ?></td>
                <th><a href="<?php echo $this->getUrl()->getUrl('form',NULL,['id'=>$customerGroup->group_id]); ?>"><i class="material-icons">edit</i></a></th>
                <th><a href="<?php echo $this->getUrl()->getUrl('delete',NULL,['id'=>$customerGroup->group_id]); ?>"><i class="material-icons red-text" >delete</i></a></th>
            </tr>
            <?php endforeach; ?>
            <?php endif; ?> 
            </tbody>
        </table>
        </p>
    </div>          
</div>
</div>
