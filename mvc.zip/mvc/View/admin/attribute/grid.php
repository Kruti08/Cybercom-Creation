<?php $attributes = $this->getAttributes(); ?>
    <div class="row">
         <div class="input-field col s12">
         <a href="<?php echo $this->getUrl()->getUrl('form'); ?>" class="addButton" name="update">Add Attribute</a>                    
        </div>
   </div>
    <div class="container-fluid">
        <div class="card text-left">
          <div class="card-body">
            <h4 class="card-title">Attribute Details</h4>
            <p class="card-text">
            <table class="highlight">
            <thead>
            <tr>
                <th>Attribute Id</th>
                <th>Entity Type ID</th>
                <th>Name</th>
                <th>Code</th>
                <th>Input Type</th>
                <th>Backend Type</th>
                <th>Sort Order</th>
                <th>Backend Model</th>
                <th colspan="3">Action</th>
            </tr>
            </thead>

            <tbody>
            <?php if(!$attributes):   ?>
                <tr>
                    <td colspan="9">No records Found</td>
                </tr>
            <?php else: ?>    
            <?php  foreach ($attributes->getData() as $key => $attribute): ?>
            <tr id="txtData">
                <td><?php echo $attribute->attributeId; ?></td>
                <td><?php echo $attribute->entityTypeId; ?></td>
                <td><?php echo $attribute->name ?></td>
                <td><?php echo $attribute->code ?></td>
                <td><?php echo $attribute->inputType ?></td>
                <td><?php echo $attribute->backendType ?></td>
                <td><?php echo $attribute->sortOrder ?></td>
                <td><?php echo $attribute->backendModel ?></td>
                <th><a href="<?php echo $this->getUrl()->getUrl('form',NULL,['id'=>$attribute->attributeId]); ?>"><i class="material-icons">edit</i></a></th>
                <th><a href="<?php echo $this->getUrl()->getUrl('delete',NULL,['id'=>$attribute->attributeId]); ?>"><i class="material-icons red-text" >delete</i></a></th>
            </tr>
           <?php  endforeach; ?>
           <?php  endif; ?> 
            </tbody>
        </table>
            </p>
          </div>
          
        </div>
       
    </div>
    