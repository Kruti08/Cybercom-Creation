<?php
   $this->getTabContent();
