<?php $cms = $this->getCms(); ?>
    <div class="row">
         <div class="input-field col s12">
         <a href="<?php echo $this->getUrl()->getUrl('form'); ?>" class="addButton" name="update">Add CMS Page</a>                    
        </div>
   </div>
    <div class="container-fluid">
        <div class="card text-left">
          <div class="card-body">
            <h4 class="card-title">CMS Page Details</h4>
            <p class="card-text">
            <table class="highlight">
            <thead>
            <tr>
                <th>Page ID</th>
                <th>Title</th>
                <th>Identifier</th>
                <th>Content</th>
                <th>Status</th>
                <th>Created At</th>
                <th colspan="3">Action</th>
            </tr>
            </thead>
            <tbody>
            <?php  if (!$cms):?>
                   <tr>
                       <td colspan="9">'No Records Found'</td>
                   </tr>
            <?php  else:  ?>
            <?php  foreach ($cms->getData() as $key => $value): ?>
            <tr id="txtData">
            <td><?php echo $value->id; ?></td>
            <td><?php echo $value->title; ?></td>
            <td><?php echo $value->identifier ?></td>
            <td><?php echo $value->content ?></td>
            <td><?php if($value->status): echo 'Enabled';  ?>
                <?php else: echo 'Disabled';?>                
                <?php endif;  ?>           
            </td>
            <td><?php echo $value->createdDate ?></td>
            <th><a href="<?php echo $this->getUrl()->getUrl('form',NULL,['id'=>$value->id]); ?>"><i class="material-icons">edit</i></a></th>
            <th><a href="<?php echo $this->getUrl()->getUrl('delete',NULL,['id'=>$value->id]); ?>"><i class="material-icons red-text" >delete</i></a></th>
            </tr>
            <?php  endforeach;  ?>
            <?php  endif; ?>
            </tbody>
        </table>
            </p>                
        </div>
       
    </div>
 