<?php
   $this->getTabContent();
?>