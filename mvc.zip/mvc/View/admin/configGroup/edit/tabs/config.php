<?php $configs = $this->getConfigs(); ?>
<div class="container">
    <div class="card text-left">
	    <div class="card-body">
    	    <h4 class="card-title">
    	    	<p class="text-center">Config Details</p>
    	    </h4>
    	<form method="post" action="<?php echo $this->getUrl()->getUrl('save','ConfigGroup\Config'); ?>">
            <div class="row">
                <div class="form-group col-md-3">
                    <button class="btn waves-effect waves-light text-light red" type="button" name="add" onclick="addConfig();">Add Option
                </button>
                </div>
                <div class="form-group col-md-3">
                <button class="btn waves-effect waves-light text-light blue" type="submit">Update Config
                </button>
                </div>
                <div class="form-group col-md-6">
                </div>
            </div>
            <div class="row" id="existingData">
            	<?php if ($configs): ?>
            		<?php foreach ($configs->getData() as $key => $config): ?>
            			<div class="form-group col-md-3">
            				<label for="title">Title</label>
                            <input id="title" name="existing[<?php echo $config->configId; ?>][title]" value="<?php echo $config->title ?>" type="text" class="validate" require>
            			</div>
            			<div class="form-group col-md-3">
            				<label for="code">Code</label>
                            <input id="code" name="existing[<?php echo $config->configId; ?>][code]" value="<?php echo $config->code ?>" type="number" class="validate" require>
            			</div>
            			<div class="form-group col-md-3">
            				<label for="value">Value</label>
                            <input id="value" name="existing[<?php echo $config->configId; ?>][value]" value="<?php echo $config->value ?>" type="number" class="validate" require>
            			</div>
            			<div class="form-group col-md-3">
                            <label for="remove">&nbsp;</label>
                            <a href="<?php echo $this->getUrl()->getUrl('delete', 'ConfigGroup\Config', ['id'=>$config->configId], true); ?>" class="btn waves-effect waves-light red" >Delete
                            <i class="material-icons black">trash</i>
                            </a>
                        </div>
            		<?php endforeach ?>
            		
            	<?php endif ?>
            </div>
    	</form>    
    	</div>
    </div>
</div>  
<div  style="display: none" id="newData">
	<div class="row" >
		<div class="form-group col-md-3">
	    	<label for="title">Title</label>
	    	<input id="title" name="new[title][]" type="text" class="validate" require>
		</div>
		<div class="form-group col-md-3">
			<label for="code">Code</label>
	        <input id="code" name="new[code][]"  type="text" class="validate" require>
		</div>
		<div class="form-group col-md-3">
			<label for="value">Value</label>
	        <input id="value" name="new[value][]"  type="text" class="validate" require>
		</div>
		<div class="form-group col-md-3">
	        <label for="remove">&nbsp;</label>
	        <a class="btn waves-effect waves-light red" onclick="removeConfig(this);">Delete<i class="material-icons black">trash</i>
	        </a>
	    </div>
	</div>
</div>

<script>
	function addConfig() {
		var existingConfig = document.getElementById('existingData');
		var newConfig = document.getElementById('newData').children[0];
		existingConfig.prepend(newConfig.cloneNode(true)) ;
	}

	function removeConfig(remove) {
		var remove = remove.parentElement.parentElement.remove();
	}
</script>  		