<?php $configGroup = $this->getConfigGroup(); ?>
<form  action="<?php echo $this->getUrl()->getUrl('save'); ?>" method="post">
    <div class="container">
        <div class="card text-left">
          <div class="card-body">
            <h4 class="card-title">
            <p class="h2 text-center">Group Details</p><br>
            </h4>
            <p class="card-text">
            <div class="row">
                <div class="col s12">
                <div class="row">
                    <div class="input-field col s12">
                    <input id="configGroupname" name="configGroup[name]" value="<?php echo $configGroup->name ?>" type="text" class="validate">
                    <label for="configGrouptname">Name</label>
                    </div>
                </div>
                <button class="btn waves-effect waves-light text-light blue" type="submit">Submit</button>
                </div>
            </div>  
            </p>
          </div>
        </div>
    </div>
    </form>