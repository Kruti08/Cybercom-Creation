<?php $configGroups = $this->getConfigGroups(); ?>
    <div class="row">
         <div class="input-field col s12">
         <a href="<?php echo $this->getUrl()->getUrl('form'); ?>" class="addButton" name="update">Add Config Group</a>                    
        </div>
   </div>
        <div class="card text-left">
          <div class="card-body">
            <h4 class="card-title"><?php echo $this->getTitle(); ?></h4>
            <p class="card-text">
            <table class="highlight">
            <thead>
            <tr>
                <th>Group ID</th>
                <th>Name</th>
                <th>Created At</th>
                <th colspan="3">Action</th>
            </tr>
            </thead>
            <tbody>
            <?php  if(!$configGroups):  ?>
                <tr>
                    <td colspan="6"><center>No records Found</center></td>
                </tr>
            <?php else: ?>    
            <?php foreach ($configGroups->getData() as $key => $configGroup): ?>
            <tr id="txtData">
                <td><?php echo $configGroup->groupId; ?></td>
                <td><?php echo $configGroup->name; ?></td>
                <td><?php echo $configGroup->createdDate ?></td>
                <th><a href="<?php echo $this->getUrl()->getUrl('form',NULL,['id'=>$configGroup->groupId]); ?>"><i class="material-icons blue-text">edit</i></a></th>
                <th><a href="<?php echo $this->getUrl()->getUrl('delete',NULL,['id'=>$configGroup->groupId ]); ?>"><i class="material-icons red-text" >delete</i></a></th>
            </tr>
           	<?php  endforeach;   ?>
        	<?php  endif; ?>
          
            </tbody>
        </table>
            </p>
          </div>
          
        </div>
       
    </div>