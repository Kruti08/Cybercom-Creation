<?php
   $this->getTabContent();
?>