<?php $payments = $this->getPayments(); ?>
    <div class="row">
         <div class="input-field col s12">
         <a href="<?php echo $this->getUrl()->getUrl('form'); ?>" class="addButton" name="update">Add Payment</a>                    
        </div>
   </div>
    <div class="container-fluid">
        <div class="card text-left">
          <div class="card-body">
            <h4 class="card-title">Payment Details</h4>
            <p class="card-text">
            <table class="highlight">
            <thead>
            <tr>
                <th>Method Id</th>
                <th>Name</th>
                <th>Code</th>
                <th>Amount</th>
                <th>Description</th>
                <th>Status</th>
                <th>Created At</th>
                <th colspan="3">Action</th>
            </tr>
            </thead>
            <tbody>
            <?php  if(!$payments):   ?>
                <tr>
                    <td colspan="10"><center>No record Found</center></td>
                </tr>
            <?php else: ?>    
            <?php foreach($payments->getData() as $payment): ?>        
            <tr id="txtData">
                <td><?php echo $payment->methodId ?></td>
                <td><?php echo $payment->name ?></td>
                <td><?php echo $payment->code ?></td>
                <td><?php echo $payment->amount ?></td>
                <td><?php echo $payment->description ?></td>
                <td><?php if($payment->status): echo 'Enabled';  ?>
                    <?php else: echo 'Disabled'; ?>    
                    <?php endif; ?>
                </td>
                <td><?php echo $payment->createdDate ?></td>
                <th><a href="<?php echo $this->getUrl()->getUrl('form',NULL,['id'=>$payment->methodId]); ?>"><i class="material-icons">edit</i></a></th>
                <th><a href="<?php echo $this->getUrl()->getUrl('delete',NULL,['id'=>$payment->methodId]); ?>"><i class="material-icons red-text" >delete</i></a></th>
            </tr>
            <?php endforeach; ?>
            <?php endif; ?>
         
            </tbody>
            </table>
            </p>            
          </div>
        </div>
    </div>
    