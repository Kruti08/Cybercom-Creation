<?php $shipments = $this->getShipment(); ?>
    <div class="row">
         <div class="input-field col s12">
         <a href="<?php echo $this->getUrl()->getUrl('form'); ?>" class="addButton" name="update">Add Shipping</a>                    
        </div>
   </div>
    <div class="container-fluid">
        <div class="card text-left">
          <div class="card-body">
            <h4 class="card-title">Shipping Details</h4>
            <p class="card-text">
            <table class="highlight">
            <thead>
            <tr>
                <th>Method Id</th>
                <th>Name</th>
                <th>Code</th>
                <th>Amount</th>
                <th>Description</th>
                <th>Status</th>
                <th>Created At</th>
                <th colspan="2">Action</th>
            </tr>
            </thead>

            <tbody>
            <?php  if(!$shipments):  ?>
                <tr>
                    <td colspan = 9><center>No records found</center></td>
                </tr>
            <?php else:  ?>    
            <?php foreach($shipments->getData() as $shipment): ?>        
            <tr id="txtData">
                <td><?php echo $shipment->methodId ?></td>
                <td><?php echo $shipment->name ?></td>
                <td><?php echo $shipment->code ?></td>
                <td><?php echo $shipment->amount ?></td>
                <td><?php echo $shipment->description ?></td>
                <td><?php if($shipment->status): echo 'Enabled';  ?>
                    <?php else: echo 'Disabled'; ?>    
                    <?php endif; ?>
                </td>
                <td><?php echo $shipment->createdDate ?></td>
                <th><a href="<?php echo $this->getUrl()->getUrl('form',NULL,['id'=>$shipment->methodId]); ?>"><i class="material-icons">edit</i></a></th>
                <th><a href="<?php echo $this->getUrl()->getUrl('delete',NULL,['id'=>$shipment->methodId]); ?>"><i class="material-icons red-text" >delete</i></a></th>
            
            </tr>
           <?php 
            endforeach;
        endif;
           ?> 
            </tbody>
        </table>
            </p>
           
          </div>
          
        </div>
       
    </div>