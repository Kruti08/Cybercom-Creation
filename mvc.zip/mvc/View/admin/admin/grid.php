<?php $admin = $this->getAdmin(); ?>
    <div class="row">
         <div class="input-field col s12">
         <a href="<?php echo $this->getUrl()->getUrl('form');?>" class="addButton" name="update">Add Admin</a>                    
        </div>
   </div>
    <div class="container-fluid">
        <div class="card text-left">
          <div class="card-body">
            <h4 class="card-title"><?php echo $this->getTitle(); ?></h4>
            <p class="card-text">
            <table class="highlight">
            <thead>
            <tr>
                <th>Admin Name</th>
                <th>Admin Status</th>
                <th>Created Date</th>
                <th colspan="2">Action</th>
            </tr>
            </thead>
            <tbody>
            <?php  if(!$admin):  ?>
                <tr>
                    <td colspan="5"><center>No records found !!</center></td>
                </tr>
            <?php else: ?>
            <?php foreach($admin->getData() as $admin): ?>
            <tr id="txtData">
                <td><?php echo $admin->adminName ?></td>
                <td><?php if($admin->status): echo 'Enabled';  ?>
                    <?php else: echo 'Disabled'; ?>    
                    <?php endif; ?>
                </td>
                <td><?php echo $admin->createdDate ?></td>
                <th><a href="<?php echo $this->getUrl()->getUrl('form',NULL,['id'=>$admin->adminId]); ?>"><i class="material-icons">edit</i></a></th>
                <th><a href="<?php echo $this->getUrl()->getUrl('delete',NULL,['id'=>$admin->adminId ]); ?>"><i class="material-icons red-text" >delete</i></a></th>
            </tr>
          <?php endforeach;  ?>
          <?php endif; ?>
            </tbody>
            </table>
            </p>
        </div>
    </div>  