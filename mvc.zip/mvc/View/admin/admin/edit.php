<?php
   $this->getTabContent();

?>