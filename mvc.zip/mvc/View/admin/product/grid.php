<?php $products = $this->getProducts(); ?>
    <div class="row">
         <div class="input-field col s12">
         <a href="<?php echo $this->getUrl()->getUrl('form'); ?>" class="addButton" name="update">Add Product</a>                    
        </div>
   </div>
        <div class="card text-left">
          <div class="card-body">
            <h4 class="card-title"><?php echo $this->getTitle(); ?></h4>
            <p class="card-text">
            <table class="highlight">
            <thead>
            <tr>
                <th>SKU</th>
                <th>Product Name</th>
                <th>Price</th>
                <th>Discount</th>
                <th>Quantity</th>
                <th>Description</th>
                <th>Status</th>
                <th>Created At</th>
                <th colspan="3">Action</th>
            </tr>
            </thead>
            <tbody>
            <?php  if(!$products):  ?>
                <tr>
                    <td colspan="11"><center>No records Found</center></td>
                </tr>
            <?php else: ?>    
            <?php foreach ($products->getData() as $key => $product): ?>
            <tr id="txtData">
                <td><?php echo $product->SKU; ?></td>
                <td><?php echo $product->productName; ?></td>
                <td><?php echo $product->productPrice ?></td>
                <td><?php echo $product->productDiscount ?></td>
                <td><?php echo $product->productQty ?></td>
                <td><?php echo $product->description ?></td>
                <td><?php if($product->status): echo 'Enabled';  ?>
                    <?php else: echo 'Disabled'; ?>    
                    <?php endif; ?>
                </td>
                <td><?php echo $product->createdDate ?></td>
                <th><a href="<?php echo $this->getUrl()->getUrl('form',NULL,['id'=>$product->productId]); ?>"><i class="material-icons blue-text">edit</i></a></th>
                <th><a href="<?php echo $this->getUrl()->getUrl('delete',NULL,['id'=>$product->productId ]); ?>"><i class="material-icons red-text" >delete</i></a></th>
                <th><a href="<?php echo $this->getUrl()->getUrl('addItemToCart',"cart",['id'=>$product->productId ]); ?>"><i class="material-icons orange-text" >shopping_cart</i></a></th>
            </tr>
           <?php 
            endforeach;
        endif;
           ?> 
            </tbody>
        </table>
            </p>
          </div>
          
        </div>
       
    </div>