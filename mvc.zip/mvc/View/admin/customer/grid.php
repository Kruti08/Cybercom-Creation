<?php $customers = $this->getCustomers(); ?>
    <div class="row">
         <div class="input-field col s12">
         <a href="<?php echo $this->getUrl()->getUrl('form'); ?>" class="addButton" name="update">Add Customer</a>                    
        </div>
   </div>
    <div class="container-fluid">
        <div class="card text-left">
          <div class="card-body">
            <h4 class="card-title">Customer Details</h4>
            <p class="card-text">
            <table class="highlight">
            <thead>
            <tr>
                <th>First Name</th>
                <th>Last Name</th>
                <th>Group Name</th>
                <th>Email</th>
                <th>Zipcode</th>
                <th>Contact No</th>
                <th>Status</th>
                <th>Created Date</th>
                <th colspan="2">Action</th>
            </tr>
            </thead>
            <tbody> 
            <?php  if(!$customers): ?>
                <tr>
                    <td colspan="9"><center>No records Found</center></td>
                </tr>
            <?php else: ?>    
            <?php foreach($customers->getData() as $customer): ?>
            <tr id="txtData">
                <td><?php echo $customer->firstName ?></td>
                <td><?php echo $customer->lastName ?></td>
                <td>
                    <?php 
                        echo $this->getGroupName($customer->group_id);
                    ?>
                </td>
                <td><?php echo $customer->email ?></td>
                <td>
                    <?php
                            echo $this->getZipCode($customer->customerId); 
                    ?>
                 </td>
                <td><?php echo $customer->contactNo ?></td>
                <td><?php if($customer->status): echo 'Enabled';  ?>
                    <?php else: echo 'Disabled'; ?>    
                    <?php endif; ?>
                </td>
                <td><?php echo $customer->createdDate ?></td>
                <th><a href="<?php echo $this->getUrl()->getUrl('form',NULL,['id'=>$customer->customerId]); ?>"><i class="material-icons">edit</i></a></th>
                <th><a href="<?php echo $this->getUrl()->getUrl('delete',NULL,['id'=>$customer->customerId]); ?>"><i class="material-icons red-text" >delete</i></a></th>          
            </tr>
           <?php 
                endforeach;
            endif;
           ?> 
            </tbody>
        </table>
            </p>
          </div>
          
        </div>
       
    </div>