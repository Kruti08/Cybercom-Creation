<!doctype html>
<html lang="en">
  <head>
    <title>Title</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
  </head>
  <body>
<div class="container-fluid">
    <div class="row">
        <?php echo $this->getChild("Header")->toHtml(); ?>
    </div>
    <div class="row">
        <?php echo $this->createBlock('Block\Core\Layout\Message')->toHtml(); ?>
    </div>
    <div class="row" style="padding: 0px 40px; ">
        <?php echo $this->getChild('Content')->toHtml();?>    
    </div>
    </div>
    <div class="row">
        <?php echo $this->getChild("Footer")->toHtml(); ?>
    </div>
</div>
<!--     <table>
        <tbody>
            <tr>
                <td scope="row" colspan="2" id = "header" height="">
                    <?php //echo $this->getChild("Header")->toHtml(); ?>
                </td>
            </tr>
            <tr>
                <td scope="row" colspan="2">
                    <?php //echo $this->createBlock('Block\Core\Layout\Message')->toHtml(); ?>
                </td>
            </tr>
            <tr height="400px" id = "content">
                <td width="400px">
                    <?php //echo $this->getChild('Content')->toHtml();?>
                </td>
            </tr>
            <tr>
                <td colspan="2" id = "footer">
                    <?php //echo $this->getChild("Footer")->toHtml(); ?>
                </td>
            </tr>
        </tbody>
    </table> -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
  </body>
</html>