<table cellpadding="0" cellspacing="0" width="100%">
    <tbody>
        <tr height="600px">
            <td>Content</td>
        </tr>
    </tbody>
</table>