<?php
namespace Model;

\Mage::loadFileByClassName('Model\Core\Table');

class Cart extends \Model\Core\Table
{

    public function __construct()
    {
        parent::__construct();
        $this->setTableName('cart');
        $this->setPrimaryKey('cartId');
    }
     
    public function addItemToCart($product,$quantity=1,$addMode=false)
    {
        $item = \Mage::getModel('Model\Cart\Item');
        $query = "SELECT * FROM `{$item->getTableName()}` WHERE `productId`={$product->productId} AND `cartId`={$this->cartId}";
        $item = $item->fetchRow($query);
        if($item){
            $item->quantity = $item->quantity + $quantity;
            $item->discount = $product->productDiscount;
            $item->basePrice = $product->productPrice;
            $item->save();
            return $this;
        }

        $item = \Mage::getModel('Model\Cart\Item');
        $item->cartId = $this->cartId;
        $item->productId = $product->productId;
        $item->price = $product->productPrice;
        $item->quantity = $quantity;
        $item->discount = $product->productDiscount * $quantity;
        $item->basePrice = $product->productPrice;
        $item->createdDate = date('Y-m-d H:i:s');
        $item->save();
        return $this;
    }

    public function getItems()
    {
        $item = \Mage::getModel('Model\Cart\Item');
        $query = "SELECT * FROM `{$item->getTableName()}` WHERE `cartId` = {$this->cartId}";
        if (!$data = $item->fetchAll($query)) {
            return false;
        }
        return $data;
    }

    public function getTotal()
    {
        $total = 0;
        $items=$this->getItems()->getData();

        foreach ($items as $key => $item) {
            $total = $total + ($item->price * $item->quantity);
        }
        return $total;
    }

    public function getDiscount()
    {
        $discount = 0;
        $items=$this->getItems()->getData();

        foreach ($items as $key => $item) {
            $discount = $discount + ((($item->price*$item->quantity)*$item->discount)/100) ;
        }
        return $discount;
    }

    public function getShippingAmount()
    {
        if(!$this->shippingMethodId){
            return null;
        }
        $shipping = \Mage::getModel('Model\Shipment');
        $query = "SELECT `amount` FROM `{$shipping->getTableName()}` WHERE `{$shipping->getPrimaryKey()}` = {$this->shippingMethodId}";
        $shippingData = $shipping->fetchRow($query);
        return $shippingData->amount;
    }

    public function getBillingAddress()
    {
        $cartAddress = \Mage::getModel('Model\Cart\Address');
        if (!$this->cartId) {
            return false;
        }
        $query = "SELECT * FROM `{$cartAddress->getTableName()}` WHERE `cartId` = '{$this->cartId}' and `addressType` = 'Billing'";
        return $cartAddress->fetchRow($query);
    }

    public function getShippingAddress()
    {
        $cartAddress = \Mage::getModel('Model\Cart\Address');
        if (!$this->cartId) {
            return false;
        }
        $query = "SELECT * FROM `{$cartAddress->getTableName()}` WHERE `cartId` = '{$this->cartId}' and `addressType` = 'Shipping'";
        return $cartAddress->fetchRow($query);
    } 

    public function getCustomers()
    {
        $customer = \Mage::getModel('Model\Customer');
        $customers = $customer->fetchAll();
        return $customers;
    }

    public function getCustomer()
    {
        $customer = \Mage::getModel('Model\Customer');
        if (!$this->customerId) {
            return $customer; 
        }
        $customer = $customer->load($this->customerId);
        return $customer;
    }

    public function getCustomerBillingAddress()
    {
        $address = \Mage::getModel('Model\CustomerAddress');
        $query = "SELECT * FROM `{$address->getTableName()}` WHERE `customerId` = {$this->customerId} AND `addressType` = 'Billing'";
        $address = $address->fetchRow($query);
        return $address;
    }

    public function getCustomerShippingAddress()
    {
        $address = \Mage::getModel('Model\CustomerAddress');
        $query = "SELECT * FROM `{$address->getTableName()}` WHERE `customerId` = {$this->customerId} AND `addressType` = 'Shipping'";
        $address = $address->fetchRow($query);
        return $address;
    }
}