<?php 

namespace Model;

\Mage::loadFileByClassName('Model\Core\Table');

class ConfigGroup extends \Model\Core\Table
{
	
	function __construct()
	{
		parent::__construct();
		$this->setTableName('config_group')->setPrimaryKey('groupId');
	}
}
 ?>