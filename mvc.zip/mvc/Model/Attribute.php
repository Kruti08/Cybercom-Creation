<?php

namespace Model;

\Mage::loadFileByClassName("Model\Core\Table");
class Attribute extends \Model\Core\Table
{
    public function __construct()
    {
        parent::__construct();
        $this->setTableName('attribute')->setPrimaryKey('attributeId');
    }

    public function getBackendTypeOption()
    {
        return [
            'varchar(255)' => 'Varchar',
            'int' => 'Int',
            'decimal' => 'Decimal',
            'text' => 'Text',
            'boolean' => 'Boolean'
        ];
    }

    public function getInputTypeOption()
    {
        return [
            'radio' => 'radio',
            'select' => 'Select',
            'checkbox' => 'Checkbox',
            'textarea' => 'Textarea',
            'textbox' => 'Textbox',
            'multiple' => 'Select Multiple',
        ];
    }

    public function getEntityType()
    {
        return [
            'product' => 'Product',
            'category' => 'Category'
        ];
    }
}
