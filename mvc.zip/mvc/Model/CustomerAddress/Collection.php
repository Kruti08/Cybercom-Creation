<?php

namespace Model\CustomerAddress;

\Mage::getModel("model\core\collection");
class Collection extends \Model\Core\Collection {
    
    public function __construct()
    {
        parent::__construct();
    }

}

?>