<?php

namespace Model\Cart;

\Mage::loadFileByClassName("Model\Core\Table");

class Address extends \Model\Core\Table
{
    public function __construct()
    {
        parent::__construct();
        $this->setTableName('cart address')->setPrimaryKey('cartAddressId');
    }

    public function getProduct()
    {
        if (!$this->cartItemId) {
            return false;
        }

        if (!$this->productId) {
            return false;
        }

        return \Mage::getModel('Model\Product')->load($this->id);
    }
}
