<?php

namespace Model\Cart;

\Mage::loadFileByClassName("Model\Core\Table");

class Item extends \Model\Core\Table
{
    public function __construct()
    {
        parent::__construct();
        $this->setTableName('cartitem')->setPrimaryKey('cartItemId');
    }
}
