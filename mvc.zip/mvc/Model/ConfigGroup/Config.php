<?php 

namespace Model\ConfigGroup;

\Mage::loadFileByClassName('Model\Core\Table');

class Config extends \Model\Core\Table
{
	
	function __construct()
	{
		$this->setTableName('config')->setPrimaryKey('configId');
	}
}

 ?>