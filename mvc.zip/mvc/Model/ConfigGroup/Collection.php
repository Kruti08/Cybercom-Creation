<?php 

namespace Model\ConfigGroup;

\Mage::getModel('Model\Core\Collection');

class Collection extends \Model\Core\Collection
{
	function __construct()
	{
		parent::__construct();
	}
}

 ?>