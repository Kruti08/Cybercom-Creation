<?php 

namespace Model\ConfigGroup\Config;

\Mage::loadFIleByClassName('Model\Core\Collection');

class Collection extends \Model\Core\Collection
{
	
	function __construct()
	{
		parent::__construct();
	}
}

 ?>