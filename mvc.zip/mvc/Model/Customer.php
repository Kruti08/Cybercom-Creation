<?php

namespace Model;

\Mage::loadFileByClassName("Model\Core\Table");
class Customer extends \Model\Core\Table{
    public function __construct()
    {
        parent::__construct();
        $this->setTableName('customer')->setPrimaryKey('customerId');
    }


    public function getBillingAddress()
    {
    	$address = \Mage::getModel('Model\CustomerAddress');
    	$query = "SELECT * FROM `{$address->getTableName()}` WHERE `customerId` = {$this->customerId} AND `addressType` = 'Billing'";
    	$address = $address->fetchRow($query);
    	return $address;
    }

    public function getShippingAddress()
    {
        $address = \Mage::getModel('Model\CustomerAddress');
        $query = "SELECT * FROM `{$address->getTableName()}` WHERE `customerId` = {$this->customerId} AND `addressType` = 'Shipping'";
        $address = $address->fetchRow($query);
        return $address;
    }
}

?>