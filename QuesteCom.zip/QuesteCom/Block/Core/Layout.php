<?php 

namespace Block\Core;

\Mage::loadFileByClassName('Block\Core\Template');

class Layout extends Template
{

	public function __construct(){
		parent::__construct();
        $this->setTemplate('./View/core/layout/threeColumn.php');
        $this->prepareChildren();
	}

	public function prepareChildren()
    {
        $header = \Mage::getBlock("Block\Core\Layout\Header");
        $this->addChild($header,"Header");

        $sidebar = \Mage::getBlock("Block\Core\Layout\Sidebar");
        $this->addChild($sidebar,"Sidebar");
                
        $content = \Mage::getBlock("Block\Core\Layout\Content");
        $this->addChild($content,"Content");

        $footer = \Mage::getBlock("Block\Core\Layout\Footer");
        $this->addChild($footer,"Footer");
        
    }
}
 ?>