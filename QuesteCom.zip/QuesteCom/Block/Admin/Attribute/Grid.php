<?php

namespace Blocl\Admin\Attribute;

\Mage::loadFileByClassName('Block\Core\Template');

class Grid extends Block_Core_Template
{
    protected $attributes = [];

    public function __construct()
    {
        $this->setTemplate('./View/admin/attribute/grid.php');
    }

    public function setAttributes($attributes = null)
    {
        if (!$attributes) {
            $attributes = \Mage::getModel('Model\admin\attribute')->fetchAll();
        }
        $this->attributes = $attributes;
        return $this;
    }

    public function getAttributes()
    {
        if (!$this->attributes) {
            $this->setAttributes();
        }
        return $this->attributes;
    }
}
