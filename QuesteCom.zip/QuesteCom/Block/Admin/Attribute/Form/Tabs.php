<?php

namespace Block\Admin\Attribute\Form;

Mage::loadFileByClassName("Block_Core_Template");

class Tabs extends \Block\Core\Template
{
    protected $tabs = [];
    protected $defaultTab = null;
    public function __construct()
    {
        parent::__construct();
        $this->setTemplate('./View/admin/attribute/form/tabs.php');
        $this->prepareTabs();
    }

    public function prepareTabs()
    {
        $this->addTabs('attribute', ['label' => 'Attribute', 'block' => 'Block\Admin\Edit\Tabs\Form']);
        if ($this->getRequest()->getGet('id')) {
            $this->addTabs('option', ['label' => 'Options', 'block' => 'Block\Admin\Attribute\Edit\Tabs\OptionGrid']);
        }
        $this->setDefaultTab('attribute');
    }

    public function setDefaultTab($defaultTab)
    {
        $this->defaultTab = $defaultTab;
        return $this;
    }

    public function getDefaultTab()
    {
        return $this->defaultTab;
    }

    public function setTabs(array $tabs)
    {
        $this->tabs = $tabs;
        return $this;
    }

    public function getTabs()
    {
        return $this->tabs;
    }

    public function addTabs($key, $tab = [])
    {
        $this->tabs[$key] = $tab;
        return $this;
    }

    public function getTab($key)
    {
        if (!array_key_exists($key, $this->tabs)) {
            return null;
        }
        return $this->tabs[$key];
    }

    public function removeTab($key)
    {
        if (!array_key_exists($key, $this->tabs)) {
            return null;
        }
        unset($this->tabs[$key]);
    }
}
