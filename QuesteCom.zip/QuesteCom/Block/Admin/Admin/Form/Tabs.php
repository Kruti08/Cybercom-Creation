<?php

namespace Block\Admin\Admin\Form;

\Mage::loadFileByClassName("Block\Core\Form\Tabs");

class Tabs extends \Block\Core\Form\Tabs
{

    protected $tabs = [];
    protected $default = null;

    public function __construct()
    {
        parent::__construct();
        $this->setTemplate("./View/admin/admin/form/tabs.php");
        $this->prepareTab();
    }

    public function prepareTab()
    {
        $this->addTab('admin', ["label" => "Admin Information", "className" => 'Block\Admin\Admin\Form\Tabs\Form']);
        $this->setDefault('admin');
    }
}
