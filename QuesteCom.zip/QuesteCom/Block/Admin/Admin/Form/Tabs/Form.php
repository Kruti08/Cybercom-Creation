<?php

namespace Block\Admin\Admin\Form\Tabs;

\Mage::loadFileByClassName("Block\Core\Template");

class Form extends \Block\Core\Template
{
    protected $admins = null;

    public function __construct()
    {
        parent::__construct();
        $this->setTemplate("./View/admin/admin/form/tabs/form.php");
    }

    public function setAdmin($admins = null)
    {
        if (!$admins) {
            $admins = \Mage::getModel("Model\Admin\Admin");
            if ($id = $this->getRequest()->getGet('id')) {
                $admin = $admins->load($id);
                if (!$admin) {
                    return null;
                }
            }
        }
        $this->admins = $admins;
        return $this;
    }

    public function getAdmin()
    {
        if (!$this->admins) {
            $this->setAdmin();
        }
        return $this->admins;
    }
}
