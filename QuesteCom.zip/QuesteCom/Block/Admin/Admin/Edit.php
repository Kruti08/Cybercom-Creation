<?php 

namespace Block\Admin\Admin;

\Mage::loadFileByClassName('Block\Core\Template');

class Edit extends \Block\Core\Template{

    public function __construct()
    {
        parent::__construct();
        $this->setTemplate('./View/admin/admin/form.php');
    }

    public function getTabContent()
    {
        $tabsObj = \Mage::getBlock("Block\Admin\Admin\Form\Tabs");
        $tabs = $tabsObj->getTabs();
        $fetchTab = $this->getRequest()->getGet('tab');
        if (!array_key_exists($fetchTab, $tabs)) {
            $fetchTab = $tabsObj->getDefault();
        }
        $gotTab = \Mage::getBlock($tabs[$fetchTab]['className']);
        echo $gotTab->toHtml();
    }
}
