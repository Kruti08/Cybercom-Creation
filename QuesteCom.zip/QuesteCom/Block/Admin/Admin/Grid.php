<?php 

namespace Block\Admin\Admin;

\Mage::loadFileByClassName('Block\Core\Template');

class Grid extends \Block\Core\Template
{
	protected $admins = null;
    protected $message = null;

    public function __construct()
    {
        parent::__construct();
        $this->setTemplate('./View/admin/admin/grid.php');
    }

    public function setAdmin($admins = null)
    {
        if (!$admins) {
            $admins = \Mage::getModel("Model\Admin\Admin");
            $admins = $admins->fetchAll();
        }
        $this->admins = $admins;
        return $this;
    }
    public function getAdmin()
    {
        if (!$this->admins) {
            $this->setAdmin();
        }
        return $this->admins;
    }
    public function getTitle()
    {
        return "Manage Admins";
    }
}
