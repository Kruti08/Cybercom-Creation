<?php

namespace Block\Admin\Category\Form;

\Mage::loadFileByClassName("Block\Core\Form\Tabs");

class Tabs extends \Block\Core\Form\Tabs
{

    protected $tabs = [];
    protected $default = null;

    public function __construct()
    {
        parent::__construct();
        $this->setTemplate("./View/admin/admin/form/tabs.php");
        $this->prepareTab();
    }

    public function prepareTab()
    {
         $this->addTab('category',["label"=>"Category Information","className"=>'Block\Admin\Category\Form\Tabs\Form']);
        $this->addTab('media',["label"=>"Media","className"=>'Block\Admin\Category\Form\Tabs\Media']);
        $this->setDefault('category');
    }
}
