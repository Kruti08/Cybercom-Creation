<?php

namespace Block\Admin\Category\Form\Tabsl

\Mage::loadClassByFileName("Block\Core\Template");
class Media extends \Block\Core\Template{

    public function __construct()
    {
        $this->setTemplate("./View/admin/category/form/tabs/media.php");
    }

}