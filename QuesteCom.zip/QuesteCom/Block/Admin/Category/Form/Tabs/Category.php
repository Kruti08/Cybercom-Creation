<?php

namespace Blocl\Admin\Category\Form\Tabs

\Mage::loadFileByClassName("Block\Core\Template");

class Category extends \Block\Core\Template{

    public function __construct()
    {
        $this->setTemplate("./View/admin/category/form/tabs/category.php");
    }

}