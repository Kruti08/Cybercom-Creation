<?php 

namespace Block\Admin\Shipment;

\Mage::loadFileByClassName('Block\Core\Template');

class Grid extends \Block\Core\Template
{
	protected $shipments = null;
    protected $message = null;

    public function __construct()
    {
        parent::__construct();
        $this->setTemplate('./View/admin/shipment/grid.php');
    }

    public function setShipment($shipments = null)
    {
        if (!$shipments) {
            $shipments = \Mage::getModel("Model\Admin\Shipment");
            $shipments = $shipments->fetchAll();
        }
        $this->shipments = $shipments;
        return $this;
    }
    public function getShipment()
    {
        if (!$this->shipments) {
            $this->setShipment();
        }
        return $this->shipments;
    }
    public function getTitle()
    {
        return "Manage Shipments";
    }
}
