<?php

namespace Block\Admin\Shipment\Form;

\Mage::loadFileByClassName("Block\Core\Form\Tabs");

class Tabs extends \Block\Core\Form\Tabs
{

    protected $tabs = [];
    protected $default = null;

    public function __construct()
    {
        parent::__construct();
        $this->setTemplate("./View/admin/admin/form/tabs.php");
        $this->prepareTab();
    }

    public function prepareTab()
    {
        $this->addTab('shipment', ["label" => "Shipment Information", "className" => 'Block\Admin\Shipment\Form\Tabs\Form']);
        $this->setDefault('shipment');
    }
}
