<?php 

namespace Block\Admin\Payment;

\Mage::loadFileByClassName('Block\Core\Template');

class Grid extends \Block\Core\Template
{
	protected $payments = null;
    protected $message = null;

    public function __construct()
    {
        parent::__construct();
        $this->setTemplate('./View/admin/payment/grid.php');
    }

    public function setPayment($payments = null)
    {
        if (!$payments) {
            $payments = \Mage::getModel("Model\Admin\Payment");
            $payments = $payments->fetchAll();
        }
        $this->payments = $payments;
        return $this;
    }
    public function getPayment()
    {
        if (!$this->payments) {
            $this->setPayment();
        }
        return $this->payments;
    }
    public function getTitle()
    {
        return "Manage Payments";
    }
}
