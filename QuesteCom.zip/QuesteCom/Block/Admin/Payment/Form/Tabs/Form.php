<?php

namespace Block\Admin\Payment\Form\Tabs;

\Mage::loadFileByClassName("Block\Core\Template");

class Form extends \Block\Core\Template
{
    protected $payments = null;

    public function __construct()
    {
        parent::__construct();
        $this->setTemplate("./View/admin/payment/form/tabs/form.php");
    }

    public function setPayment($payments = null)
    {
        if (!$payments) {
            $payments = \Mage::getModel("Model\Admin\Payment");
            if ($id = $this->getRequest()->getGet('id')) {
                $payment = $payments->load($id);
                if (!$payment) {
                    return null;
                }
            }
        }
        $this->payments = $payments;
        return $this;
    }

    public function getPayment()
    {
        if (!$this->payments) {
            $this->setPayment();
        }
        return $this->payments;
    }
}
