<?php 

namespace Block\Admin\Customer;

\Mage::loadFileByClassName('Block\Core\Template');

class Grid extends \Block\Core\Template
{
	protected $customers = null;
    protected $message = null;

    public function __construct()
    {
        parent::__construct();
        $this->setTemplate('./View/admin/customer/grid.php');
    }

    public function setCustomer($customers = null)
    {
        if (!$customers) {
            $customers = \Mage::getModel("Model\Admin\Customer");
            $customers = $customers->fetchAll();
        }
        $this->customers = $customers;
        return $this;
    }
    public function getCustomer()
    {
        if (!$this->customers) {
            $this->setCustomer();
        }
        return $this->customers;
    }
    public function getTitle()
    {
        return "Manage customers";
    }
}
