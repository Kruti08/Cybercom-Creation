<?php
namespace Block\Admin\Customer\Form\Tabs;

\Mage::loadFileByClassName('Block\Core\Template');
class Address extends \Block\Core\Template
{
    protected $customer = null;
    protected $shippingAddress = null;
    protected $billingAddress = null;
    protected $billingData = null;
    protected $shippingData = null;

    public function __construct()
    {
        parent::__construct();
        $this->setTemplate('./View/admin/customer/form/tabs/address.php');
    }

    public function setCustomer(\Model\Admin\Customer $customer)
    {
        $this->customer = $customer;
        return $this;
    }
    public function getCustomer()
    {
        return $this->customer;
    }
    public function setShippingAddress()
    {
        $this->shippingAddress = \Mage::getModel('Model\Admin\Customer\Address');
        $shipping = "SELECT * FROM `customer_address` WHERE  `customerId`= '{$this->getCustomer()->id}' AND `addressType`= 'Shipping';";
        $this->shippingData = $this->shippingAddress->fetchRow($shipping);
        if (!$this->shippingData) {
            return $this->shippingAddress;
        }
        $this->shippingAddress = $this->shippingData;
        return $this;
    }
    public function getShippingAddress()
    {
        if (!$this->shippingAddress) {
            $this->setShippingAddress();
        }
        return $this->shippingAddress;
    }
    public function setBillingAddress()
    {
        $this->billingAddress = \Mage::getModel('Model\Admin\Customer\Address');
        $billing = "SELECT * FROM `customer_address` WHERE  `customerId`= '{$this->getCustomer()->id}' AND `addressType`= 'Billing';";
        $this->billingData = $this->billingAddress->fetchRow($billing);
        if (!$this->billingData) {
            return $this->billingAddress;
        }
        $this->billingAddress = $this->billingData;
        return $this;
    }
    public function getBillingAddress()
    {
        if (!$this->billingAddress) {
            $this->setBillingAddress();
        }
        return $this->billingAddress;
    }

}