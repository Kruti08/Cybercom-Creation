<?php

namespace Block\Admin\Customer\Form\Tabs;

\Mage::loadFileByClassName("Block\Core\Template");

class Form extends \Block\Core\Template
{
    protected $customers = null;

    public function __construct()
    {
        parent::__construct();
        $this->setTemplate("./View/admin/customer/form/tabs/form.php");
    }

    public function setCustomer($customers = null)
    {
        if (!$customers) {
            $customers = \Mage::getModel("Model\Admin\Customer");
            if ($id = $this->getRequest()->getGet('id')) {
                $customer = $customers->load($id);
                if (!$customer) {
                    return null;
                }
            }
        }
        $this->customers = $customers;
        return $this;
    }

    public function getCustomer()
    {
        if (!$this->customers) {
            $this->setCustomer();
        }
        return $this->customers;
    }
}
