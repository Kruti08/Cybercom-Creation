<?php

namespace Block\Admin\Customer\Form;

\Mage::loadFileByClassName("Block\Core\Form\Tabs");

class Tabs extends \Block\Core\Form\Tabs
{

    protected $tabs = [];
    protected $default = null;

    public function __construct()
    {
        parent::__construct();
        $this->setTemplate("./View/admin/customer/form/tabs.php");
        $this->prepareTab();
    }

    public function prepareTab()
    {
        $this->addTab('customer', ["label" => "Customer Information", "className" => 'Block\Admin\Customer\Form\Tabs\Form']);
        $this->addTab('address', ["label" => "Address", "className" => 'Block\Admin\Customer\Form\Tabs\Address']);
        $this->setDefault('customer');
    }
}
