<?php 

namespace Block\Admin\CustomerGroup;

\Mage::loadFileByClassName('Block\Core\Template');

class Grid extends \Block\Core\Template
{
	protected $customerGroups = null;
    protected $message = null;

    public function __construct()
    {
        parent::__construct();
        $this->setTemplate('./View/admin/customerGroup/grid.php');
    }

    public function setCustomerGroup($customerGroups = null)
    {
        if (!$customerGroups) {
            $customerGroup = \Mage::getModel("Model\Admin\CustomerGroup");
            $customerGroups = $customerGroup->fetchAll();
        }
        $this->customerGroups = $customerGroups;
        return $this;
    }
    public function getCustomerGroup()
    {
        if (!$this->customerGroups) {
            $this->setCustomerGroup();
        }
        return $this->customerGroups;
    }
    public function getTitle()
    {
        return "Manage Customer Groups";
    }
}
