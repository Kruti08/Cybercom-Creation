<?php

namespace Block\Admin\CustomerGroup\Form;

\Mage::loadFileByClassName("Block\Core\Form\Tabs");

class Tabs extends \Block\Core\Form\Tabs
{
    protected $tabs = [];
    protected $default = null;

    public function __construct()
    {
        parent::__construct();
        $this->setTemplate("./View/admin/customerGroup/form/tabs.php");
        $this->prepareTab();
    }

    public function prepareTab()
    {
        $this->addTab('customerGroup', ["label" => "Customer Group Information", "className" => 'Block\Admin\customerGroup\Form\Tabs\Form']);

        $this->setDefault('customerGroup');
    }
}
