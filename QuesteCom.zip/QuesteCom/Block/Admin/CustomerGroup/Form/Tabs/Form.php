<?php

namespace Block\Admin\CustomerGroup\Form\Tabs;

\Mage::loadFileByClassName("Block\Core\Template");

class Form extends \Block\Core\Template
{
    protected $customerGroups = null;

    public function __construct()
    {
        parent::__construct();
        $this->setTemplate("./View/admin/customerGroup/form/tabs/form.php");
    }

    public function setCustomerGroup($customerGroups = null)
    {
        if (!$customerGroups) {
            $customerGroups = \Mage::getModel("Model\Admin\CustomerGroup");
            if ($id = $this->getRequest()->getGet('id')) {
                $customerGroup = $customerGroups->load($id);
                if (!$customerGroup) {
                    return null;
                }
            }
        }
        $this->customerGroups = $customerGroups;
        return $this;
    }

    public function getCustomerGroup()
    {
        if (!$this->customerGroups) {
            $this->setCustomerGroup();
        }
        return $this->customerGroups;
    }
}
