<?php

namespace Block\Admin\CustomerGroup\Form\Tabs;

\Mage::loadFileByClassName("Block\Core\Template");

class Media extends Block_Core_Template
{
    public function __construct()
    {
        parent::__construct();
        $this->setTemplate("./View/admin/product/form/tabs/media.php");
    }

    public function getMedia($id)
    {
        $mediaModel = \Mage::getModel("Model\Admin\Product\Media");
        $query = "select * from `productmedia` where `productId` =" . $id;
        $media = $mediaModel->fetchAll($query);
        return $media;
    }
}
