<?php 

namespace Block\Admin\Product;

\Mage::loadFileByClassName('Block\Core\Template');

class Grid extends \Block\Core\Template
{
	protected $products = null;
    protected $message = null;

    public function __construct()
    {
        parent::__construct();
        $this->setTemplate('./View/admin/product/grid.php');
    }

    public function setProduct($products = null)
    {
        if (!$products) {
            $products = \Mage::getModel("Model\Admin\Product");
            $products = $products->fetchAll();
        }
        $this->products = $products;
        return $this;
    }
    public function getProduct()
    {
        if (!$this->products) {
            $this->setProduct();
        }
        return $this->products;
    }
    public function getTitle()
    {
        return "Manage products";
    }
}
