<?php

namespace Block\Admin\Product\Form;

\Mage::loadFileByClassName("Block\Core\Form\Tabs");

class Tabs extends \Block\Core\Form\Tabs
{

    protected $tabs = [];
    protected $default = null;

    public function __construct()
    {
        parent::__construct();
        $this->setTemplate("./View/admin/product/form/tabs.php");
        $this->prepareTab();
    }

    public function prepareTab()
    {
        $this->addTab('product', ["label" => "Product Information", "className" => 'Block\Admin\Product\Form\Tabs\Form']);
        if ($this->getRequest()->getGet('id')) {
            $this->addTab('media', ["label" => "Media", "className" => 'Block\Admin\Product\Form\Tabs\Media']);
        }

        $this->addTab('category', ["label" => "Category", "className" => 'Block\Admin\Product\Form\Tabs\Category']);
        $this->setDefault('product');
    }
}
