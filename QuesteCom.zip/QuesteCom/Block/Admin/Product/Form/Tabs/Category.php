<?php

namespace Block\Admin\Product\Form\Tabs;

\Mage::loadFileByClassName("Block\Core\Template");

class Category extends \Block\Core\Template{

    public function __construct()
    {
        $this->setTemplate("./View/admin/product/form/tabs/category.php");
    }

}