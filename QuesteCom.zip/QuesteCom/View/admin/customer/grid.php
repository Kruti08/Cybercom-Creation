<?php $customers = $this->getCustomer(); ?>
<br>
<div class="container">
<div class="row">
        <div class="col-sm" id="title">Customer Details</div>
        <div class="col-sm"></div>
        <div class="col-sm"><a href="<?php echo $this->getUrl()->getUrl('form');?>" class="btn btn-danger" id="addButton"><i class="fas fa-plus-circle"></i>&nbspAdd Customer</a></div>
</div> 
<br>
<div class="table-responsive">
    <table class="table table-hover" id="gridTable">
    <thead class="thead-dark">
        <tr>
            <th scope="col">Id</th>
            <th scope="col">Group Id</th>
            <th scope="col">First Name</th>
            <th scope="col">Last Name</th>
            <th scope="col">Email</th>
            <th scope="col">Contact No</th>
            <th scope="col">Status</th>
            <th scope="col">Created At</th>
            <th scope="col">Action</th>
        </tr>
    </thead>
    <tbody>
        <?php  if (!$customers) {  ?>
                <tr>
                	<td colspan="6">
                	<strong><?php echo 'No Records Found'; ?></strong>
                	</td>
                </tr>
                <?php  } else {  foreach ($customers->getData() as $key => $value) { ?>
            <tr>
                <th scope="row"><?php echo $value->customerId ?></td>
                <td><?php echo $value->group_id ?></td>
                <td><?php echo $value->firstName ?></td>
                <td><?php echo $value->lastName ?></td>
                <td><?php echo $value->firstName ?></td>
                <td><?php echo $value->contactNo ?></td>
                <?php if ($value->status == 1) :?>
                <td><span class="status text-success"><button class="bg-success">Enable</button></td>
                <?php  else :?>
                <td><span class="status text-warning"><button class="bg-danger">Disable</button></td>
                <?php endif; ?>
                <td><?php echo $value->createdDate ?></td>
                <td>
                    <a href="<?php echo $this->getUrl()->getUrl('form',null, ['id' => $value->customerId],false) ?>" class="edit"
                        title="Edit" data-toggle="tooltip"><i class="far fa-edit"></i>
                    <a href="<?php echo $this->getUrl()->getUrl('delete',null, ['id' => $value->customerId],false) ?>"
                        class="delete" title="Delete" data-toggle="tooltip"><i class="fas fa-trash"></i></a>
                </td>
                    </tr>
                    <?php   } }?>
    </tbody>
</table>
</div>
</div>