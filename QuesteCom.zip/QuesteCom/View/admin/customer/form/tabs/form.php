<?php $customer= $this->getcustomer(); ?> 
<?php $customerModel = \Mage::getModel('Model\Admin\customer'); ?>
    <br><br>
        	<form action="<?php echo $this->getUrl()->getUrl('save'); ?>" method="post">
                <div class="form-group col-lg-12">
            		<?php if ($this->getRequest()->getGet('id')) { ?>
                            <p class="form-title">Update customer Details</p><br>
                        <?php } else { ?>
                            <p class="form-title">Add customer Details</p><br>
                        <?php } ?>
        		</div>
                <div class="form-row">
                    <div class="form-group col-md-6">
                        <label class="label" for="status">Customer Group</label>
                        <select id="status" class="form-control" name="customer[group_id]">
                            <option value="---" disabled selected></option>
                            <option value="1">Wholeseller</option>
                            <option value="2">Retailer</option>
                        </select></div>
                    <div class="form-group col-md-6">
                        <label class="label" for="status"><b>Status</b></label><br>
                        <select id="status" name="product[status]" class="form-control">
                        <?php foreach ($customerModel->getStatusOptions() as $key => $value) {?>
                        <option value="<?php echo $key ?>" <?php if ($customer->status == $key) {?> selected <?php }?>>
                        <?php echo $value ?></option>  <?php  } ?>
                    </select>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group col-md-6">
                        <label for="firstName">FIRST NAME</label>
                        <input id="firstName" name="customer[firstName]" value="<?php echo $customer->firstName ?>" type="text" placeholder="FIRST NAME" class="validate form-control" require>
                    </div>
                    <div class="form-group col-md-6">
                        <label for="lastName">LAST NAME</label>
                        <input id="lastName" name="customer[lastName]" value="<?php echo $customer->lastName ?>" type="text" placeholder="LAST NAME" class="validate form-control">
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group col-md-6">
                        <label for="price">EMAIL</label>
                        <input id="price" name="customer[email]" value="<?php echo $customer->email ?>" type="text" placeholder="EMAIL" class="validate form-control" require>
                    </div>
                    <div class="form-group col-md-4">
                        <label for="password">PASSWORD</label>
                        <input id="password" name="customer[password]" value="<?php echo $customer->password ?>" type="text" placeholder="PASSWORD" class="validate form-control" require>
                    </div>
                </div>
                <button type="submit" class="btn btn-danger submitButton" style="margin: 0">Submit</button>  
            </form> 
            