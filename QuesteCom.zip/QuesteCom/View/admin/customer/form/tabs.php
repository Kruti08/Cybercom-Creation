<?php

$tabs = $this->getTabs();
$urlTab = $this->getRequest()->getGet('tab');

foreach ($tabs as $key => $value) {
    $active = ""; ?>
    <a href="<?php echo $this->getUrl()->getUrl(null, null, ["tab" => $key]); ?>" class="btn btn-warning text-center tabButton  <?php echo ($key == $urlTab) ? "active" : ""; ?>">
        <?php echo $value['label'] ?>
    </a>
<?php } ?>