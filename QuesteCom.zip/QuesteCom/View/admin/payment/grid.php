<?php $payment = $this->getPayment(); ?>
<br>
<div class="container">
<div class="row">
        <div class="col-sm" id="title">Payment Details</div>
        <div class="col-sm"></div>
        <div class="col-sm"><a href="<?php echo $this->getUrl()->getUrl('form');?>" class="btn btn-danger" id="addButton"><i class="fas fa-plus-circle"></i>&nbspAdd Admin</a></div>
</div> 
<br>
<div class="table-responsive">
    <table class="table table-hover" id="gridTable">
    <thead class="thead-dark">
        <tr>
            <th scope="col">Name</th>
            <th scope="col">Code</th>
            <th scope="col">Amount</th>
            <th scope="col">Description</th>
            <th scope="col">Status</th>
            <th scope="col">CreatedDate</th>
            <th scope="col">Action</th>
        </tr>
    </thead>
    <tbody>
        <?php  if (!$payment) {  ?>
                <tr>
                	<td colspan="9">
                	<strong><?php echo 'No Records Found'; ?></strong>
                	</td>
                </tr>
                <?php  } else {  foreach ($payment->getData() as $key => $value) { ?>
            <tr>
                <th scope="row"><?php echo $value->name ?></td>
                <td><?php echo $value->code ?></td>
                <td><?php echo $value->amount ?></td>
                <td><?php echo $value->description ?></td>
                <?php if ($value->status == 1) :?>
                <td><span class="status text-success"><button class="bg-success">Enable</button></td>
                <?php  else :?>
                <td><span class="status text-warning"><button class="bg-danger">Disable</button></td>
                <?php endif; ?>
                <td><?php echo $value->createdDate ?></td>
                <td>
                    <a href="<?php echo $this->getUrl()->getUrl('form',null, ['id'=>$value->methodId],false); ?>" class="edit"
                        title="Edit" data-toggle="tooltip"><i class="far fa-edit"></i></a>
                    <a href="<?php echo $this->getUrl()->getUrl('delete',null, ['id'=>$value->methodId],false); ?>"
                        class="delete" title="Delete" data-toggle="tooltip"><i class="fas fa-trash"></i></a>
                </td>
                    </tr>
                    <?php   } }?>
    </tbody>
</table>
</div>
</div>