<?php
	$this->getTabContent();
?>