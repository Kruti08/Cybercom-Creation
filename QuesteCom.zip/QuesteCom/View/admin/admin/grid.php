<?php $admins = $this->getAdmin(); ?>
<br>
<div class="container">
<div class="row">
        <div class="col-sm" id="title">Admin Details</div>
        <div class="col-sm"></div>
        <div class="col-sm"><a href="<?php echo $this->getUrl()->getUrl('form');?>" class="btn btn-danger" id="addButton"><i class="fas fa-plus-circle"></i>&nbspAdd Admin</a></div>
</div> 
<br>
<div class="table-responsive">
    <table class="table table-hover" id="gridTable">
    <thead class="thead-dark">
        <tr>
            <th scope="col">Id</th>
            <th scope="col">Admin Name</th>
            <th scope="col">Admin Username</th>
            <th scope="col">Admin Status</th>
            <th scope="col">CreatedDate</th>
            <th scope="col">Action</th>
        </tr>
    </thead>
    <tbody>
        <?php  if (!$admins) {  ?>
                <tr>
                	<td colspan="6">
                	<strong><?php echo 'No Records Found'; ?></strong>
                	</td>
                </tr>
                <?php  } else {  foreach ($admins->getData() as $key => $value) { ?>
            <tr>
                <th scope="row"><?php echo $value->adminId ?></td>
                <td><?php echo $value->adminName ?></td>
                <td><?php echo $value->adminUsername ?></td>
                <?php if ($value->status == 1) :?>
                <td><span class="status text-success"><button class="bg-success">Enable</button></td>
                <?php  else :?>
                <td><span class="status text-warning"><button class="bg-danger">Disable</button></td>
                <?php endif; ?>
                <td><?php echo $value->createdDate ?></td>
                <td>
                    <a href="<?php echo $this->getUrl()->getUrl('form',null, ['id' => $value->adminId],false) ?>" class="edit"
                        title="Edit" data-toggle="tooltip"><i class="far fa-edit"></i>
                    <a href="<?php echo $this->getUrl()->getUrl('delete',null, ['id' => $value->adminId],false) ?>"
                        class="delete" title="Delete" data-toggle="tooltip"><i class="fas fa-trash"></i></a>
                </td>
                    </tr>
                    <?php   } }?>
    </tbody>
</table>
</div>
</div>