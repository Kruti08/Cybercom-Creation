<?php
    $product = $this->getProduct();
    $productModel = \Mage::getModel('Model\Admin\Product');
?> 
<div class="container">
<br><br>
        	<form method="post" action="<?php echo $this->getUrl()->getUrl('save'); ?>" >	
                <div class="form-group col-lg-12">
            		<?php if ($this->getRequest()->getGet('id')) { ?>
                            <p class="h2 text-center">Update Product Details</p><br>
                        <?php } else { ?>
                            <p class="h2 text-center">Add Product Details</p><br>
                        <?php } ?>
        		</div>
                <div class="form-row">
                    <div class="form-group col-md-6">
                        <label class="label" for="sku"><b>SKU</b></label>
                        <input class="form-control" id="sku" name="product[SKU]" class="" type="text"
                        value="<?php echo $product->SKU ?>" required>
                    </div>
                    <div class="form-group col-md-6">
                        <label class="label" for="name"><b>Name</b></label>
                        <input class="form-control" id="name" name="product[productName]" class="" type="text"
                        value="<?php echo $product->productName ?>" required>               
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group col-md-6">
                        <label class="label" for="price"><b>Price</b></label>
                        <input class="form-control" id="price" name="product[productPrice]" class="" type="text"
                        value="<?php echo $product->productPrice ?>" required>   
                    </div>
                    <div class="form-group col-md-6">
                        <label class="label" for="discount"><b>Discount</b></label>
                        <input class="form-control" id="discount" name="product[productDiscount]" class="" type="text"
                        value="<?php echo $product->productDiscount ?>" required>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group col-md-6">
                        <label class="label" for="quantity"><b>Quantity</b></label>
                        <input class="form-control" id="quantity" name="product[productQty]" type="number"
                        value="<?php echo $product->productQty ?>" required><br> 
                    </div>
                    <div class="form-group col-md-6">
                        <label class="label" for="status"><b>Status</b></label><br>
                        <select id="status" name="product[status]" class="form-control">
                        <?php foreach ($productModel->getStatusOptions() as $key => $value) {?>
                        <option value="<?php echo $key ?>" <?php if ($product->status == $key) {?> selected <?php }?>>
                        <?php echo $value ?></option>  <?php  } ?>
                    </select><br>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group col-md-12">
                        <label class="label" for="description"><b>Description</b></label>
                        <textarea name="product[description]" id="description" class="form-control" cols="30" rows="3"
                        value="<?php echo $product->description ?>"><?php echo $product->description ?></textarea><br>
                    </div>
                </div>
                <button type="submit" class="btn btn-warning" style="margin: 0">Submit</button>  
            </form> 
        </div>
        <div class="col-lg-2"></div>

    </div>
</div>              