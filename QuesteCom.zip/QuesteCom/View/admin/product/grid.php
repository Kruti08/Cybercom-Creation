<?php  $products = $this->getProduct()->getData();  $count = 1; ?>
<br>
<div class="container">
<div class="row">
        <div class="col-sm" id="title">Product Details</div>
        <div class="col-sm"></div>
        <div class="col-sm"><a href="<?php echo $this->getUrl()->getUrl('form'); ?>" class="btn btn-danger" id="addButton"><i class="fas fa-plus-circle"></i>&nbspAdd Product</a></div>
</div> 
<br>
<div class="table-responsive">
    <table class="table table-hover" id="gridTable">
    <thead class="thead-dark">
        <tr>
            <th scope="col">Id</th>
            <th scope="col">SKU</th>
            <th scope="col">Name</th>
            <th scope="col">Price</th>
            <th scope="col">Discount</th>
            <th scope="col">Quentity</th>
            <th scope="col">Description</th>
            <th scope="col">Status</th>
            <th scope="col">CreatedDate</th>
            <th scope="col">UpdatedDate</th>
            <th scope="col">Action</th>
        </tr>
    </thead>
    <tbody>
        <?php  if (!$products) {  ?>
                <tr>
                    <td colspan="11">
                    <strong><?php echo 'No Records Found'; ?></strong>
                    </td>
                </tr>
                <?php } else { foreach ($products as $key => $product) { ?>
            <tr>
                <th scope="row"><?php echo $product->productId ?></td>
                <td><?php echo $product->SKU ?></td>
                <td><?php echo $product->productName ?></td>
                <td><?php echo $product->productPrice ?></td>
                <td><?php echo $product->productDiscount ?></td>
                <td><?php echo $product->productQty ?></td>
                <td><?php echo $product->description ?></td>
                <?php if ($product->status == 1) :?>
                <td><span class="status text-success"><button class="bg-success">Enable</button></td>
                <?php  else :?>
                <td><span class="status text-warning"><button class="bg-danger">Disable</button></td>
                <?php endif; ?>
                <td><?php echo $product->createdDate ?></td>
                <td><?php echo $product->updatedDate ?></td>
                <td>
                    <div class="buttons">
                        <a href="<?php echo $this->getUrl()->getUrl('form', null,['id' => $product->productId]) ?>" class="edit"
                        title="Edit" data-toggle="tooltip"><i class="far fa-edit"></i></a>
                        <a href="<?php echo $this->getUrl()->getUrl('delete', null,['id' => $product->productId]) ?>"
                        class="delete" title="Delete" data-toggle="tooltip"><i class="fas fa-trash"></i></a>
                    </div>
                </td>
            </tr> 
        <?php }} ?>
    </tbody>
</table>
</div>
</div>
