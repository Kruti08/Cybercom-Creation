<?php $customerGroups = $this->getCustomerGroup()->getData(); ?>
<br>
<div class="container">
<div class="row">
        <div class="col-lg-7" id="title">Customer Group Details</div>
        <div class="col-lg-1"></div>
        <div class="col-lg-4"><a href="<?php echo $this->getUrl()->getUrl('form');?>" class="btn btn-danger" id="addButton"><i class="fas fa-plus-circle"></i>&nbspAdd Customer Group</a></div>
</div>
<br>
<div class="table-responsive">
    <table class="table table-hover" id="gridTable">
    <thead class="thead-dark">
        <tr>
            <th scope="col">Id</th>
            <th scope="col">Name</th>
            <th scope="col">customer Status</th>
            <th scope="col">CreatedDate</th>
            <th scope="col">Action</th>
        </tr>
    </thead>
    <tbody>
        <?php  if (!$customerGroups) {  ?>
                <tr>
                	<td colspan="5">
                	<strong><?php echo 'No Records Found'; ?></strong>
                	</td>
                </tr>
                <?php  } else {  foreach ($customerGroups as $key => $customerGroup) { ?>
            <tr>
                <th scope="row"><?php echo $customerGroup->group_id ?></td>
                <td><?php echo $customerGroup->name ?></td>
                <?php if ($customerGroup->status == 1) :?>
                <td><span class="status text-success"><button class="bg-success">Enable</button></td>
                <?php  else :?>
                <td><span class="status text-warning"><button class="bg-danger">Disable</button></td>
                <?php endif; ?>
                <td><?php echo $customerGroup->createdDate ?></td>
                <td>
                    <a href="<?php echo $this->getUrl()->getUrl('form',null, ['id' => $customerGroup->group_id],false) ?>" class="edit"
                        title="Edit" data-toggle="tooltip"><i class="far fa-edit"></i>
                    <a href="<?php echo $this->getUrl()->getUrl('delete',null, ['id' => $customerGroup->group_id],false) ?>"
                        class="delete" title="Delete" data-toggle="tooltip"><i class="fas fa-trash"></i></a>
                </td>
                    </tr>
                    <?php   } }?>
    </tbody>
</table>
</div>
</div>