<?php $category= $this->getCategory(); 
$categoryOptions = $this->getCategoryOptions(); 
$categoryModel = \Mage::getModel('Model\Admin\Category');
?>

    <br><br>
        	<form action="<?php echo $this->getUrl()->getUrl('save'); ?>" method="post">
                <div class="form-group col-lg-12">
            		<?php if ($this->getRequest()->getGet('id')) { ?>
                            <p class="h2 text-center">Update Category Details</p><br>
                        <?php } else { ?>
                            <p class="h2 text-center">Add Category Details</p><br>
                        <?php } ?>
        		</div>
                <div class="form-row">
                    <div class="form-group col-md-12">
                            <label for="parentId">PARENT ID</label>
                            <select class="form-control" id="parentId" name="category[parentId]">
                                <?php if ($categoryOptions) : ?>
                                    <?php foreach ($categoryOptions as $categoryId => $name) : ?>
                                        <option value="<?php echo $categoryId ?>" <?php echo ($categoryId == $category->parentId) ? 'selected' : ""; ?>><?php echo $name; ?></option>
                                    <?php endforeach; ?>
                                
                            
                                
                                <?php endif; ?>

                            </select>
                        </div>
                </div>
                <div class="form-row">
                    <div class="form-group col-md-12">
                        <label class="label" for="name"><b>category Username</b></label>
                        <input class="form-control" id="name" name="category[categoryUsername]" class="" type="text"
                        value="<?php echo $category->categoryUsername ?>" required> </center>              
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group col-md-12">
                        <label class="label" for="status"><b>Status</b></label><br>
                        <select id="status" name="category[status]" class="form-control">
                        <?php foreach ($categoryModel->getStatusOptions() as $key => $value) {?>
                        <option value="<?php echo $key ?>" <?php if ($category->status == $key) {?> selected <?php }?>>
                        <?php echo $value ?></option>  <?php  } ?>
                    </select><br>
                    </div>
                </div>
                <button type="submit" class="btn btn-danger submitButton" style="margin: 0">Submit</button>  
            </form> 
            