<?php $categories  = $this->getCategory(); ?>
<br>
<div class="container">
<div class="row">
        <div class="col-sm" id="title">Category Details</div>
        <div class="col-sm"></div>
        <div class="col-sm"><a href="<?php echo $this->getUrl()->getUrl('form');?>" class="btn btn-danger" id="addButton"><i class="fas fa-plus-circle"></i>&nbspAdd Category</a></div>
</div> 
<br>
<div class="table-responsive">
    <table class="table table-hover" id="gridTable">
    <thead class="thead-dark">
        <tr>
            <th scope="col">Category Id</th>
            <th scope="col">Category Name</th>
            <th scope="col">Parent Id</th>
            <th scope="col">Path Id</th>
            <th scope="col">Status</th>
            <th scope="col">Description</th>
            <th scope="col">Action</th>
        </tr>
    </thead>
    <tbody>
        <?php  if (!$categories) {  ?>
                <tr>
                	<td colspan="6">
                	<strong><?php echo 'No Records Found'; ?></strong>
                	</td>
                </tr>
                <?php  } else {  foreach ($categories ->getData() as $key => $category) { ?>
            <tr>
                <th scope="row"><?php echo $category->categoryId ?></th>
                <td><?php echo $this->getName($category); ?></td>
                <td><?php echo $category->parentId ?></td>
                <td><?php echo $category->pathId ?></td>
                <?php if ($category->status == 1) :?>
                <td><span class="status text-success"><button class="bg-success">Enable</button></td>
                <?php  else :?>
                <td><span class="status text-warning"><button class="bg-danger">Disable</button></td>
                <?php endif; ?>
                <td><?php echo $category->description ?></td>
                <td>
                    <a href="<?php echo $this->getUrl()->getUrl('form',null, ['id' => $category->categoryId],false) ?>" class="edit"
                        title="Edit" data-toggle="tooltip"><i class="far fa-edit"></i>
                    <a href="<?php echo $this->getUrl()->getUrl('delete',null, ['id' => $category->categoryId],false) ?>"
                        class="delete" title="Delete" data-toggle="tooltip"><i class="fas fa-trash"></i></a>
                </td>
                    </tr>
                    <?php   } }?>
    </tbody>
</table>
</div>
</div>