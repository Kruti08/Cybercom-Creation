<!-- <html>
	<head>
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css">
	<link rel="stylesheet" href="http://localhost/QuesteCom/Skin/css/style.css">
	<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.bundle.min.js"></script>
	<script src="https://kit.fontawesome.com/11649ed825.js" crossorigin="anonymous"></script>
</head>
</html>
<body> -->
	<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
		<a class="navbar-brand" href="#">QuesteCom</a>
  		<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
    	<span class="navbar-toggler-icon"></span>
  		</button>
  		<div class="collapse navbar-collapse" id="navbarNav">
    		<ul class="navbar-nav">
    			<li class="nav-item">
		    		<a class="nav-link" href="http://localhost/QuesteCom/index.php?a=grid&c=Admin_Admin">Admin</a>
		  		</li>
      			<li class="nav-item active">
		    		<a class="nav-link" href="http://localhost/QuesteCom/index.php?a=grid&c=Admin_Product">Product</span></a>
		  		</li>
		  		<li class="nav-item">
		    		<a class="nav-link" href="http://localhost/QuesteCom/index.php?a=grid&c=Admin_Category">Category</a>
		  		</li>
		  		<li class="nav-item">
		    		<a class="nav-link" href="http://localhost/QuesteCom/index.php?a=grid&c=Admin_Customer">Customer</a>
		  		</li>
		  		<li class="nav-item">
		    		<a class="nav-link" href="http://localhost/QuesteCom/index.php?a=grid&c=Admin_CustomerGroup">Customer Group</a>
		  		</li>
		  		<li class="nav-item">
		    		<a class="nav-link" href="http://localhost/QuesteCom/index.php?a=grid&c=Admin_Payment">Payment</a>
		  		</li>
		  		<li class="nav-item">
		    		<a class="nav-link" href="http://localhost/QuesteCom/index.php?a=grid&c=Admin_Shipment">Shipment</a>
		  		</li>
			</ul>
			</div>
  		</div>
</nav>