<head>
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css">
	<link rel="stylesheet" href="http://localhost/QuesteCom/Skin/css/style.css">
	<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.bundle.min.js"></script>
	<script src="https://kit.fontawesome.com/11649ed825.js" crossorigin="anonymous"></script>
</head>
<body>
<div>
	 <?php echo $this->getChild('Header')->toHtml();  ?> 
</div>
<div class="row">
	<div class="col-2" style="height: 600px"></div>
	<div class="col-8"><?php echo $this->createBlock('Block\Core\Layout\Message')->toHtml(); ?>
                <?php echo  $this->getChild("Content")->toHtml(); ?></div>
	<div class="col-2" id="rightCol"></div>
</div>
<div style="height:40px">
	<?php echo $this->getChild('Footer')->toHtml();?>
</div>
</body>


