<div class="footer">
  	<p>Made By: Kruti Panchal</p>
</div>