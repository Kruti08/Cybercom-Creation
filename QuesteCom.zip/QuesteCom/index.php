<?php 

class Mage{
	public static function init(){
		self::loadFileByClassName("Controller\Core\Front");
		\Controller\Core\Front::init();
	}

	public static function getController($controllerName){
		self::loadFileByClassName($controllerName);
		$controllerName = ucfirst(str_replace('\\', ' ', $controllerName));
		$controllerName = str_replace(' ', '\\', $controllerName);
		return new $controllerName();
	}

	public static function getModel($modelName){
		self::loadFileByClassName($modelName);
		$modelName = ucfirst(str_replace('_', ' ', $modelName));
		$modelName = str_replace(' ', '_', $modelName);
		return new $modelName();
	}

	public static function getBlock($blockName){
		self::loadFileByClassName($blockName);
		$blockName = ucfirst(str_replace('\\', ' ', $blockName));
		$blockName = str_replace(' ', '\\', $blockName);
		return new $blockName();
	}

	public static function loadFileByClassName($classname){
		$classname = ucfirst(str_replace('\\', ' ', $classname));
		$classname = str_replace(' ', '\\', $classname).".php";
		require_once($classname);
	}

	public static function prepareClassName($key, $nameSpace)
    {

        $className = $key . "_" . $nameSpace;
        $className = ucwords(str_replace('_', ' ', $className));
        $className = str_replace(' ', '\\', $className);
        return $className;
    }
}

Mage::init();
?>
