<?php

namespace Controller\Admin;

\Mage::loadFileByClassName('Controller\Core\Admin');

class Shipment extends \Controller\Core\Admin
{
    public function __construct()
    {
        parent::__construct();
    }

    public function gridAction()
    {
        $gridBlock=\Mage::getBlock("Block\Admin\Shipment\Grid");
        $layout=$this->getLayout();
        $layout->setTemplate("./View/core/layout/twoColumn.php");
        $layout->getChild("Content")->addChild($gridBlock, 'Grid');
        $this->renderLayout();
    }

    public function formAction()
    {

        $layout=$this->getLayout();
        $form=\Mage::getBlock('Block\Admin\Shipment\Edit');
        $layout->getChild('Content')->addChild($form, 'Grid');
        $shipmentTab=\Mage::getBlock("Block\Admin\Shipment\Form\Tabs");
        $layout->getChild('Sidebar')->addChild($shipmentTab, 'Tab');
        $this->renderLayout();
    }

    public function saveAction()
    {
        try {
            $shipment=\Mage::getModel("Model\Admin\Shipment");
            if (!$this->getRequest()->isPost()) {
                throw new Exception("Invalid Post Request");
            }
            $shipmentId=$this->getRequest()->getGet('id');
            if (!$shipmentId) {
                date_default_timezone_set('Asia/Kolkata');
                $shipment->createdDate=date("Y-m-d H:i:s");
                $this->getMessage()->setSuccess("Shipment Inserted !!");
            } else {
                $shipment= $shipment->load($shipmentId);
                if (!$shipment) {
                    throw new Exception("Data Not Found");
                }
                $this->getMessage()->setSuccess("Shipment Updated !!");
            }
            $shipmentData=$this->getRequest()->getPost('shipment');
            if (!array_key_exists('status', $shipmentData)) {
                $shipmentData['status']=0;
            } else {
                $shipmentData['status']=1;
            }
            $shipment->setData($shipmentData);
            $shipment->save();
        } catch (Exception $e) {
            $this->getMessage()->setFailure($e->getMessage());
        }
        $this->redirect('grid', null, null, true);
    }

    // public function changeStatusAction()
    // {
    //     try {
    //         $id=$this->getRequest()->getGet('id');
    //         $st=$this->getRequest()->getGet('status');
    //         $model=\Mage::getModel('Model\Admin\Shipment');
    //         $model->id=$id;
    //         $model->status=$st;
    //         $model->changeStatus();
    //         if ($model->changeStatus()) {
    //             $this->getMessage()->setSuccess("Admin Status Change Successfully !!");
    //         }
    //     } catch (\Exception $e) {
    //         $this->getMessage()->setFailure($e->getMessage());
    //     }
    //     $this->redirect('grid', null, null, true);
    // }

    public function deleteAction()
    {
        try {
            if ($this->request->isPost()) {
                throw new \Exception("Invalid Request");
            }

            $id=$this->getRequest()->getGet('id');
            $delModel=\Mage::getModel('Model\Admin\Shipment');
            $delModel->id=$id;
            $delModel->delete();
            if ($delModel->delete()) {
                $this->getMessage()->setSuccess("Shipment method Deleted Successfully !!");
            } else {
                $this->getMessage()->setFailure("Unable To Delete Shipment method !!");
            }
        } catch (\Exception $e) {
            $this->getMessage()->setFailure($e->getMessage());
        }
        $this->redirect('grid', null, null, true);
    }
}
