<?php

namespace Controller\Admin;

\Mage::loadFileByClassName('Controller\Core\Admin');

class CustomerGroup extends \Controller\Core\Admin
{
    public function __construct()
    {
        parent::__construct();
    }

    public function gridAction()
    {
        $gridBlock = \Mage::getBlock("Block\Admin\CustomerGroup\Grid");
        $layout = $this->getLayout();
        $layout->setTemplate("./View/core/layout/twoColumn.php");
        $layout->getChild("Content")->addChild($gridBlock, 'Grid');
        $this->renderLayout();
    }

    public function formAction()
    {

        $layout = $this->getLayout();
        $form = \Mage::getBlock('Block\Admin\CustomerGroup\Edit');
        $layout->getChild('Content')->addChild($form, 'Grid');
        $customerGroupTab = \Mage::getBlock("Block\Admin\CustomerGroup\Form\Tabs");
        $layout->getChild('Sidebar')->addChild($customerGroupTab, 'Tab');
        $this->renderLayout();
    }

    public function saveAction()
    {
        try {
            $customerGroup = \Mage::getModel("Model\Admin\CustomerGroup");
            if (!$this->getRequest()->isPost()) {
                throw new \Exception("Invalid Post Request");
            }
            $customerGroupId = $this->getRequest()->getGet('id');
            if ($customerGroupId) {
                $customerGroup=$customerGroup->load($customerGroupId);
                if (!$customerGroup) {
                    throw new \Exception("No Data Available");
                }
                $this->getMessage()->setSuccess("Customer Group Updated Successfully !!");
            } else {
                $this->getMessage()->setSuccess("Customer Group Inserted Successfully !!");
            }
            $customerGroupData = $this->getRequest()->getPost('customerGroup');

            if (!array_key_exists('status', $customerGroupData)) {
                $customerGroupData['status'] = 0;
            } else {
                $customerGroupData['status'] = 1;
            }
            $customerGroup->setData($customerGroupData);
            $customerGroup->createdDate = date("Y-m-d H:i:s");
            $customerGroup->save();
        } catch (\Exception $e) {
            $this->getMessage()->setFailure($e->getMessage());
        }
        $this->redirect('grid', null, null, true);
    }
    // public function changeStatusAction()
    // {
    //     try {
    //         $id = $this->getRequest()->getGet('id');
    //         $st = $this->getRequest()->getGet('status');
    //         $model = \Mage::getModel('Model\Admin\CustomerGroup');
    //         $model->id = $id;
    //         $model->status = $st;
    //         $model->changeStatus();
    //         if ($model->changeStatus()) {
    //             $this->getMessage()->setSuccess("Customer F Status Change Successfully !!");
    //         }
    //     } catch (\Exception $e) {
    //         $this->getMessage()->setFailure($e->getMessage());
    //     }
    //     $this->redirect('grid', null, null, true);
    // }
    public function deleteAction()
    {
        try {
            if ($this->request->isPost()) {
                throw new \Exception("Invalid Request");
            }

            $id = $this->getRequest()->getGet('id');
            $delModel = \Mage::getModel('Model\Admin\CustomerGroup');
            $delModel->id = $id;
            $delModel->delete();
            if ($delModel->delete()) {
                $this->getMessage()->setSuccess("Customer Group Deleted Successfully !!");
            } else {
                $this->getMessage()->setFailure("Unable To Delete Customer Group !!");
            }
        } catch (\Exception $e) {
            $this->getMessage()->setFailure($e->getMessage());
        }
        $this->redirect('grid', null, null, true);
    }
}
