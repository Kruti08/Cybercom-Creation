<?php

namespace Controller\Admin;

\Mage::loadFileByClassName('Controller\Core\Admin');

class Payment extends \Controller\Core\Admin
{
    public function __construct()
    {
        parent::__construct();
    }

    public function gridAction()
    {
        $gridBlock = \Mage::getBlock("Block\Admin\Payment\Grid");
        $layout = $this->getLayout();
        $layout->setTemplate("./View/core/layout/twoColumn.php");
        $layout->getChild("Content")->addChild($gridBlock, 'Grid');
        $this->renderLayout();
    }

    public function formAction()
    {
        $layout = $this->getLayout();
        $form = \Mage::getBlock('Block\Admin\Payment\Edit');
        $layout->getChild('Content')->addChild($form, 'Grid');
        $paymentTab = \Mage::getBlock("Block\Admin\Payment\Form\Tabs");
        $layout->getChild('Sidebar')->addChild($paymentTab, 'Tab');
        $this->renderLayout();
    }

    public function saveAction()
    {
        try {
            $payment = \Mage::getModel("Model\Admin\Payment");
            if (!$this->getRequest()->isPost()) {
                throw new Exception("Invalid Post Request");
            }
            $paymentId = $this->getRequest()->getGet('id');
            if (!$paymentId) {
                date_default_timezone_set('Asia/Kolkata');
                $payment->createdDate = date("Y-m-d H:i:s");
                $this->getMessage()->setSuccess("Payment Done !!");
            } else {
                $payment=$payment->load($paymentId);
                if (!$payment) {
                    throw new \Exception("Data Not Found");
                }
                $this->getMessage()->setSuccess("Payment Updated !!");
            }
            $paymentData = $this->getRequest()->getPost('payment');
            if (!array_key_exists('status', $paymentData)) {
                $paymentData['status'] = 0;
            } else {
                $paymentData['status'] = 1;
            }
            $payment->setData($paymentData);
            $payment->save();
        } catch (\Exception $e) {
            $this->getMessage()->setFailure($e->getMessage());
        }
        $this->redirect('grid', null, null, true);
    }

    // public function changeStatusAction()
    // {
    //     try {
    //         $id = $this->getRequest()->getGet('id');
    //         $st = $this->getRequest()->getGet('status');
    //         $model = \\Mage::getModel('Model\Admin\Paymentt');
    //         $model->id = $id;
    //         $model->status = $st;
    //         $model->changeStatus();
    //         if ($model->changeStatus()) {
    //             $this->getMessage()->setSuccess("Admin Status Change Successfully !!");
    //         }
    //     } catch (\Exception $e) {
    //         $this->getMessage()->setFailure($e->getMessage());
    //     }
    //     $this->redirect('grid', null, null, true);
    // }
    
    public function deleteAction()
    {
        try {
            if ($this->request->isPost()) {
                throw new \Exception("Invalid Request");
            }

            $id = $this->getRequest()->getGet('id');
            $delModel = \Mage::getModel('Model\Admin\Payment');
            $delModel->id = $id;
            $delModel->delete();
            if ($delModel->delete()) {
                $this->getMessage()->setSuccess("Payment method Deleted Successfully !!");
            } else {
                $this->getMessage()->setFailure("Unable To Delete Payment method !!");
            }
        } catch (\Exception $e) {
            $this->getMessage()->setFailure($e->getMessage());
        }
        $this->redirect('grid', null, null, true);
    }
}
