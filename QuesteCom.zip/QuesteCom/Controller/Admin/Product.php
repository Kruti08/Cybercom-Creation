<?php

namespace Controller\Admin;

\Mage::loadFileByClassName('Controller\Core\Admin');

class Product extends \Controller\Core\Admin
{
    public function __construct()
    {
        parent::__construct();
    }

    public function gridAction()
    {
        $gridBlock=\Mage::getBlock("Block\Admin\Product\Grid");
        $layout=$this->getLayout();
        $layout->setTemplate("./View/core/layout/twoColumn.php");
        $layout->getChild("Content")->addChild($gridBlock, 'Grid');
        $this->renderLayout();
    }

    public function formAction()
    {

        $layout=$this->getLayout();
        $form=\Mage::getBlock('Block\Admin\Product\Edit');
        $layout->getChild('Content')->addChild($form, 'Grid');
        $adminTab=\Mage::getBlock("Block\Admin\Product\Form\Tabs");
        $layout->getChild('Sidebar')->addChild($adminTab, 'Tab');
        $this->renderLayout();
    }

    public function saveAction()
    {
        try {
            $product=\Mage::getModel("Model\Admin\Product");
            if (!$this->getRequest()->isPost()) {
                throw new \Exception("Invalid Post Request", 1);
            }
            $productId=$this->getRequest()->getGet('id');
            if (!$productId) {
                date_default_timezone_set('Asia/Kolkata');
                $product->createdDate=date("Y-m-d H:i:s");
                $this->getMessage()->setSuccess("Product Inserted SuccessFully !!");
            } else {
                $product=$product->load($productId);
                if (!$product) {
                    throw new \Exception("Data Not Found", 1);
                }
                date_default_timezone_set('Asia/Kolkata');
                $product->updatedDate=date("y-m-d h:i:s");
                $product->productId=$productId;
                $this->getMessage()->setSuccess("Product Updated SuccessFully !!");
            }
            $productData=$this->getRequest()->getPost('product');
            if (!array_key_exists('status', $productData)) {
                $productData['status']=0;
            } else {
                $productData['status']=1;
            }
            $product->setData($productData);
            $product->save();
        } catch (\Exception $e) {
            $this->getMessage()->setFailure($e->getMessage());
        }
        $this->redirect('grid', null, null, true);
    }
    
    public function deleteAction()
    {
        try {
            if ($this->request->isPost()) {
                throw new \Exception("Invalid Request");
            }

            $id=$this->getRequest()->getGet('id');
            $delModel=\Mage::getModel('Model\Admin\Product');
            $delModel->id=$id;
            $delModel->delete();
            if ($delModel->delete()) {
                $this->getMessage()->setSuccess("Product Deleted Successfully !!");
            } else {
                $this->getMessage()->setFailure("Unable To Delete Product !!");
            }
        } catch (\Exception $e) {
            $this->getMessage()->setFailure($e->getMessage());
        }
        $this->redirect('grid', null, null, true);
    }
}
