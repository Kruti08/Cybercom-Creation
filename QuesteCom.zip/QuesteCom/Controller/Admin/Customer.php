<?php

namespace Controller\Admin;

\Mage::loadFileByClassName('Controller\Core\Admin');

class Customer extends \Controller\Core\Admin
{
    public function __construct()
    {
        parent::__construct();
    }

    public function gridAction()
    {
        $gridBlock = \Mage::getBlock("Block\Admin\Customer\Grid");
        $layout = $this->getLayout();
        $layout->setTemplate("./View/core/layout/twoColumn.php");
        $layout->getChild("Content")->addChild($gridBlock, 'Grid');
        $this->renderLayout();
    }

    public function formAction()
    {

        $layout = $this->getLayout();
        $form = \Mage::getBlock('Block\Admin\Customer\Edit');
        $layout->getChild('Content')->addChild($form, 'Grid');
        $customerTab = \Mage::getBlock("Block\Admin\Customer\Form\Tabs");
        $layout->getChild('Sidebar')->addChild($customerTab, 'Tab');
        $this->renderLayout();
    }

    public function saveAction()
    {
        try {
            $customer = \Mage::getModel("Model\Admin\Customer");
            if (!$this->getRequest()->isPost()) {
                throw new \Exception("Invalid Post Request");
            }
            $customerId = $this->getRequest()->getGet('id');
            if ($customerId) {
                $customer=$customer->load($customerId);
                if (!$customer) {
                    throw new \Exception("No Data Available");
                }
                date_default_timezone_set('Asia/Kolkata');
                $customer->createdDate = date("Y-m-d H:i:s");
                $this->getMessage()->setSuccess("Customer Updated Successfully !!");
            } else {
                $this->getMessage()->setSuccess("Customer Inserted Successfully !!");
            }
            $customerData = $this->getRequest()->getPost('customer');
            if (!array_key_exists('status', $customerData)) {
                $customerData['status'] = 0;
            } else {
                $customerData['status'] = 1;
            }
            $customer->setData($customerData);
            $customer->createdDate = date("Y-m-d H:i:s");
            $customer->save();
        } catch (\Exception $e) {
            $this->getMessage()->setFailure($e->getMessage());
        }
        $this->redirect('grid', null, null, true);
    }

    // public function changeStatusAction()
    // {
    //     try {
    //         $id = $this->getRequest()->getGet('id');
    //         $st = $this->getRequest()->getGet('status');
    //         $model = \Mage::getModel('Model\Admin\Customer');
    //         $model->id = $id;
    //         $model->status = $st;
    //         $model->changeStatus();
    //         if ($model->changeStatus()) {
    //             $this->getMessage()->setSuccess("Admin Status Change Successfully !!");
    //         }
    //     } catch (\Exception $e) {
    //         $this->getMessage()->setFailure($e->getMessage());
    //     }
    //     $this->redirect('grid', null, null, true);
    // }

    public function deleteAction()
    {
        try {
            if ($this->request->isPost()) {
                throw new \Exception("Invalid Request");
            }

            $id = $this->getRequest()->getGet('id');
            $delModel = \Mage::getModel('Model\Admin\Customer');
            $delModel->id = $id;
            $delModel->delete();
            if ($delModel->delete()) {
                $this->getMessage()->setSuccess("Customer Deleted Successfully !!");
            } else {
                $this->getMessage()->setFailure("Unable To Delete Customer !!");
            }
        } catch (\Exception $e) {
            $this->getMessage()->setFailure($e->getMessage());
        }
        $this->redirect('grid', null, null, true);
    }
}
