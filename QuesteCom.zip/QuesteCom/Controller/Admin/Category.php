<?php 

namespace Controller\Admin;

\Mage::loadFileByClassName('Controller\Core\Admin');

class Category extends \Controller\Core\Admin
{
    public function __construct()
    {
        parent::__construct();
    }

    public function gridAction()
    {
        $gridBlock=\Mage::getBlock("Block\Admin\Category\Grid");
        $layout=$this->getLayout();
        $layout->setTemplate("./View/core/layout/twoColumn.php");
        $layout->getChild("Content")->addChild($gridBlock, 'Grid');
        $this->renderLayout();
    }

    public function editAction()
    {
        try {
            if (!($id=$this->getRequest()->getGet('id'))) {
                throw new \Exception("Id Not Found", 1);
            }
            $layout=$this->getLayout();
            $categoryTab=\Mage::getBlock("Block\Admin\Category\Form\Tabs");
            $layout->getChild('Sidebar')->addChild($categoryTab, 'Tab');

            $form=\Mage::getBlock('Block\Category\Form');
            $layout->getChild('Content')->addChild($form, 'Grid');

            $this->renderLayout();
        } catch (\Exception $e) {
            $this->getMessage()->setFailure($e->getMessage());
            $this->redirect('grid');
        }
    }

    public function formAction()
    {
        $layout=$this->getLayout();
        $form=\Mage::getBlock('Block\Admin\Category\Edit');
        $layout->getChild('Content')->addChild($form, 'Grid');
        $adminTab=\Mage::getBlock("Block\Admin\Category\Form\Tabs");
        $layout->getChild('Sidebar')->addChild($adminTab, 'Tab');
        $this->renderLayout();
    }

    public function saveAction()
    {
        try {
            $category=\Mage::getModel('Model\Admin\Category');    
            $categoryData = $this->getRequest()->getPost('category');
            $category->setData($categoryData);
            if ($id = $this->getRequest()->getGet('id')) {
                $category = $category->load($id);
                if (!$category) {
                    throw new \Exception('InValid ID');
                }
               
                $this->getMessage()->setSuccess('Record Updated Successfully !!');
                
            } else {
                
                $this->getMessage()->setSuccess('Record Inserted Successfully !!');
            }
            $categoryPathId = $category->pathId;
            $category->updatePathId();
            $category->updateChildrenPathIds($categoryPathId);
        } catch (\Exception $e) {
            $this->getMessage()->setFailure($e->getMessage());
            $this->redirect('grid', null, [], true);
        }
        $this->redirect('grid', null, [], true);
    }

    // public function changeStatusAction()
    // {
    //     try {
    //         $id=$this->getRequest()->getGet('id');
    //         $st=$this->getRequest()->getGet('status');
    //         $model=\Mage::getModel('Model\Admin\Admin');
    //         $model->id=$id;
    //         $model->status=$st;
    //         $model->changeStatus();
    //         if ($model->changeStatus()) {
    //             $this->getMessage()->setSuccess("Admin Status Change Successfully !!");
    //         }
    //     } catch (\Exception $e) {
    //         $this->getMessage()->setFailure($e->getMessage());
    //     }
    //     $this->redirect('grid', null, null, true);
    // }
    public function deleteAction()
    {
        try {
            $category = \Mage::getModel('Model\Admin\Category');
            if ($id = $this->getRequest()->getGet('id')) {
                $category=$category->load($id);
                if (!$category) {
                    throw new \Exception("Invalid ID");
                }
            }
            $parentId=$category->parentId;
            $pathId=$category->pathId;
            $category->updateChildrenPathIds($pathId, $parentId);
            $category->id=$category->categoryId;
            $category->delete();
        } catch (\Exception $e) {
            $this->getMessage()->setFailure($e->getMessage());
        }
        $this->redirect('grid', null, null, true);
    }
}
